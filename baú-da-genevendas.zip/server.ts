import express from 'express';
import path from 'path';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { authenticateToken, requireAdmin, AuthenticatedRequest } from './server/middleware/auth';
import { 
  sendAdminNotification, 
  setAdminDeviceToken, 
  getAdminDeviceToken 
} from './server/services/firebaseAdmin';
import { db } from './server/db/users';

dotenv.config();

const JWT_SECRET = process.env.JWT_SECRET || 'chave_secreta_genevendas_dev';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // ==========================================
  // HEALTH CHECK
  // ==========================================
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // ==========================================
  // DISPOSITIVO PRINCIPAL / PUSH NOTIFICATIONS
  // ==========================================

  // Rota para salvar o Token do seu dispositivo principal (Salva no Banco de Dados)
  app.post('/api/admin/register-device', async (req: express.Request, res: express.Response) => {
    const { token } = req.body || {};
    
    // Obter autorização se presente
    const authHeader = req.headers['authorization'];
    const authToken = authHeader && authHeader.split(' ')[1];
    let userId = 'usr-admin-001';

    if (authToken) {
      try {
        const decoded = jwt.verify(authToken, JWT_SECRET) as { id: string; role: string; email: string };
        if (decoded?.id) {
          userId = decoded.id;
        }
      } catch {
        // Ignora erro e usa usuário admin padrão
      }
    }

    if (!token) {
      return res.status(400).json({ error: 'Token não fornecido' });
    }

    try {
      // 1. Atualiza o token do usuário no banco de dados
      await db.query(
        'UPDATE users SET fcm_token = $1 WHERE id = $2',
        [token, userId]
      );

      // 2. Salva em memória de fallback
      setAdminDeviceToken(token);
      console.log(`Token FCM associado ao usuário ${userId} no banco de dados:`, token);

      return res.status(200).json({ 
        success: true, 
        message: 'Token salvo com sucesso no banco de dados!',
        userId,
        token 
      });
    } catch (error) {
      console.error('Erro ao salvar token no banco de dados:', error);
      return res.status(500).json({ error: 'Erro ao salvar token no servidor' });
    }
  });

  // ==========================================
  // ROTAS PÚBLICAS (Qualquer visitante acessa)
  // ==========================================

  // Listar produtos
  app.get('/api/products', (req, res) => {
    res.json({
      message: 'Lista pública de produtos do Baú da Genevendas',
      status: 'success',
    });
  });

  // Rota de Login (Gera o Token JWT com a role do usuário)
  app.post('/api/login', (req, res) => {
    const { email, role } = req.body || {};
    
    // Payload do usuário
    const userPayload = {
      id: req.body?.id || 'usr-admin-001',
      email: email || 'admin@baugenevendas.com',
      role: (role === 'admin' || email === 'genesisdadulce10@gmail.com' || email === 'admin@baugenevendas.com') ? 'admin' : 'user',
    };

    const token = jwt.sign(userPayload, JWT_SECRET, {
      expiresIn: '8h',
    });

    res.json({
      token,
      user: userPayload,
      message: 'Autenticado com sucesso no Baú da Genevendas',
    });
  });

  // ==========================================
  // ROTAS DE USUÁRIO AUTENTICADO
  // ==========================================

  // Criar novo anúncio (Requer autenticação)
  app.post('/api/products', async (req: express.Request, res: express.Response) => {
    const product = req.body;
    const title = product?.title || 'Novo Item';

    // Notificar quando um novo produto for anunciado
    await sendAdminNotification(
      'Novo Anúncio Criado!',
      `Um novo produto foi publicado no Baú da Genevendas: "${title}".`,
      { productId: String(product?.id || '') }
    );

    res.status(201).json({
      success: true,
      message: 'Produto cadastrado',
      product,
    });
  });

  // Notificar quando uma mensagem for enviada no chat
  app.post('/api/messages', async (req: express.Request, res: express.Response) => {
    const { message, senderName, roomTitle } = req.body || {};

    // Notificar quando uma mensagem for enviada no chat
    await sendAdminNotification(
      'Nova Mensagem no Chat',
      senderName 
        ? `${senderName} enviou uma nova mensagem sobre "${roomTitle || 'um anúncio'}".` 
        : `Você recebeu uma nova mensagem sobre um anúncio.`,
      { message: String(message || '') }
    );

    res.status(200).json({ 
      success: true, 
      message: 'Mensagem enviada com notificação' 
    });
  });

  // ==========================================
  // PAGAMENTOS MULTICAIXA EXPRESS
  // ==========================================
  app.post('/api/payments/checkout', async (req: express.Request, res: express.Response) => {
    const { amount, customerPhone, duration, productId } = req.body || {};
    const apiKey = process.env.PAYMENT_GATEWAY_SECRET_KEY;
    const merchantPhone = process.env.MERCHANT_EXPRESS_PHONE || '924258402';
    const merchantName = process.env.MERCHANT_NAME || 'Bau_da_Genevendas';

    if (!customerPhone) {
      return res.status(400).json({
        success: false,
        message: 'Número de telefone do cliente é obrigatório para pagamento Express.',
      });
    }

    try {
      // Se a chave da gateway de pagamento estiver configurada
      if (apiKey && apiKey !== 'sua_chave_api_da_gateway') {
        const gatewayResponse = await fetch('https://api.gatewaypagamento.co.ao/v1/charges', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            amount: Number(amount) || 1000, // 1000 ou 10500 AOA
            currency: 'AOA',
            payment_method: 'EXPRESS',
            customer_phone: customerPhone, // Número que o usuário digitou para pagar
            merchant_phone: merchantPhone, // Seu número: 924258402
            reference_id: `PRODUCT_${productId || 'GENEVENDAS'}`,
          }),
        });

        const result = await gatewayResponse.json();

        if (gatewayResponse.ok) {
          // Dispara notificação push para o administrador
          await sendAdminNotification(
            '💳 Pagamento Express Solicitado',
            `Cobrança de ${amount || 1000} Kz enviada para o telefone ${customerPhone}.`,
            { type: 'payment_express', productId: String(productId || ''), amount: String(amount || 1000) }
          );

          return res.status(200).json({
            success: true,
            message: 'Solicitação de pagamento enviada para o Express do cliente.',
            data: result,
          });
        } else {
          return res.status(400).json({
            success: false,
            message: 'Erro ao gerar cobrança Express.',
            details: result,
          });
        }
      }

      // Fallback seguro em modo de desenvolvimento / simulação
      const referenceCode = `EXP-${Math.floor(100000 + Math.random() * 900000)}`;

      await sendAdminNotification(
        '💳 Pagamento Express Solicitado',
        `Cobrança de ${amount || 1000} Kz gerada para o telefone ${customerPhone} (Ref: ${referenceCode}).`,
        { type: 'payment_express', productId: String(productId || ''), amount: String(amount || 1000) }
      );

      return res.status(200).json({
        success: true,
        message: 'Solicitação de pagamento enviada para o Express do cliente.',
        data: {
          id: `charge_${Date.now()}`,
          status: 'pending_authorization',
          amount: Number(amount) || 1000,
          currency: 'AOA',
          payment_method: 'EXPRESS',
          customer_phone: customerPhone,
          merchant_phone: merchantPhone,
          merchant_name: merchantName,
          reference: referenceCode,
          duration: duration || 7,
          instructions: 'Abra o seu aplicativo Multicaixa Express no celular e autorize a transação.',
        },
      });
    } catch (error) {
      console.error('Erro na chamada da gateway de pagamento:', error);
      return res.status(500).json({ error: 'Erro de conexão com o servidor de pagamento.' });
    }
  });

  // ==========================================
  // COMPRA DIRETA DE PRODUTO COM SPLIT DE 5% DE COMISSÃO
  // ==========================================
  app.post('/api/orders/checkout', async (req: express.Request, res: express.Response) => {
    const { productId, productPrice, buyerPhone, sellerPhone, productTitle } = req.body || {};
    const price = Number(productPrice) || 0;
    const apiKey = process.env.PAYMENT_GATEWAY_SECRET_KEY;
    const merchantPhone = process.env.MERCHANT_EXPRESS_PHONE || '924258402';

    if (!buyerPhone) {
      return res.status(400).json({ error: 'Número de telefone do comprador é obrigatório.' });
    }

    // 1. Cálculo do Desconto Automático de 5% do Site
    const commissionFee = Math.round(price * 0.05); // 5% retidos pela sua plataforma
    const sellerPayout = price - commissionFee;     // 95% enviados para o vendedor

    try {
      if (apiKey && apiKey !== 'sua_chave_api_da_gateway') {
        // 2. Chamada à Gateway para débito automático no Express do comprador
        const paymentResponse = await fetch('https://api.gatewaypagamento.co.ao/v1/charges', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            amount: price,
            currency: 'AOA',
            customer_phone: buyerPhone,
            payment_method: 'EXPRESS',
            reference_id: `ORDER_${productId || Date.now()}`,
            // Distribuição do valor pago
            split_rules: [
              {
                merchant_phone: merchantPhone, // Seu Express: 924258402
                amount: commissionFee,         // Recebe 5% da venda
              },
              {
                merchant_phone: sellerPhone || merchantPhone, // Express do Vendedor
                amount: sellerPayout,          // Recebe 95% da venda
              },
            ],
          }),
        });

        const result = await paymentResponse.json();

        if (paymentResponse.ok) {
          await sendAdminNotification(
            '🛒 Nova Compra no Site!',
            `Venda de "${productTitle || 'Produto'}" por ${price} Kz. Sua comissão de 5%: ${commissionFee} Kz.`,
            { type: 'order_checkout', productId: String(productId || ''), amount: String(price) }
          );

          return res.status(200).json({
            success: true,
            message: 'Compra efetuada com sucesso!',
            summary: {
              totalPaid: price,
              siteFee: commissionFee,
              sellerReceived: sellerPayout,
            },
            data: result,
          });
        } else {
          return res.status(400).json({ 
            error: 'Falha no processamento do pagamento.',
            details: result 
          });
        }
      }

      // Fallback em modo de desenvolvimento / simulação
      const orderRef = `PED-${Math.floor(100000 + Math.random() * 900000)}`;

      await sendAdminNotification(
        '🛒 Nova Venda no Baú da Genevendas!',
        `Compra de "${productTitle || 'Produto'}" no valor de ${price.toLocaleString('pt-AO')} Kz. Comissão do site (5%): ${commissionFee.toLocaleString('pt-AO')} Kz.`,
        { type: 'order_checkout', productId: String(productId || ''), amount: String(price) }
      );

      return res.status(200).json({
        success: true,
        message: 'Solicitação de compra enviada para o Multicaixa Express do comprador!',
        summary: {
          totalPaid: price,
          siteFee: commissionFee,
          sellerReceived: sellerPayout,
          reference: orderRef,
        },
      });
    } catch (error) {
      console.error('Erro na rota /api/orders/checkout:', error);
      return res.status(500).json({ error: 'Erro interno no servidor de pagamentos.' });
    }
  });

  // ==========================================
  // ROTAS ADMINISTRATIVAS (ACESSO TOTAL)
  // ==========================================

  // Deletar QUALQUER anúncio do sistema (Apenas Admin)
  app.delete('/api/admin/products/:id', authenticateToken, requireAdmin, (req: AuthenticatedRequest, res) => {
    const { id } = req.params;
    res.json({
      success: true,
      message: `Anúncio ${id} removido com sucesso pelo Administrador (${req.user?.email}).`,
      deletedId: id,
    });
  });

  // Alterar status/cargo de qualquer usuário ou moderação global
  app.patch('/api/admin/users/:id/role', authenticateToken, requireAdmin, (req: AuthenticatedRequest, res) => {
    const { id } = req.params;
    const { role } = req.body;
    res.json({
      success: true,
      message: `Permissões do usuário ${id} atualizadas para ${role} pelo Administrador.`,
      userId: id,
      newRole: role,
    });
  });

  // ==========================================
  // VITE MIDDLEWARE / STATIC FILES
  // ==========================================
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Servidor Baú da Genevendas rodando em http://0.0.0.0:${PORT}`);
  });
}

startServer();
