import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

// Interface para expandir o tipo Request do Express e incluir as informações do usuário logado
export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    role: 'user' | 'admin';
  };
}

// Chave secreta obtida das variáveis de ambiente (com valor de fallback para desenvolvimento)
const JWT_SECRET = process.env.JWT_SECRET || 'chave_secreta_genevendas_dev';

/**
 * Middleware 1: Verifica se o usuário está autenticado via Token JWT
 */
export const authenticateToken = (
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers['authorization'];
  // O formato esperado é "Bearer <TOKEN>"
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({
      error: 'Acesso negado',
      message: 'Token de autenticação não fornecido.',
    });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as AuthenticatedRequest['user'];
    req.user = decoded; // Anexa as informações do usuário à requisição
    next();
  } catch {
    return res.status(403).json({
      error: 'Sessão inválida',
      message: 'Token expirado ou inválido.',
    });
  }
};

/**
 * Middleware 2: Exige permissões de Administrador (Acesso Total)
 * Deve ser encadeado APÓS o authenticateToken.
 */
export const requireAdmin = (
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
) => {
  if (!req.user) {
    return res.status(401).json({
      error: 'Não autenticado',
      message: 'Faça login para continuar.',
    });
  }

  if (req.user.role !== 'admin') {
    return res.status(403).json({
      error: 'Acesso proibido',
      message: 'Esta ação requer privilégios de administrador.',
    });
  }

  next(); // Usuário é Admin, libera o acesso total
};
