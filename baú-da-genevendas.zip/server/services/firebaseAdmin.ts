import { initializeApp, cert, getApps, App } from 'firebase-admin/app';
import { getMessaging, Messaging } from 'firebase-admin/messaging';
import { db } from '../db/users';

let firebaseApp: App | null = null;
let messagingService: Messaging | null = null;
let ADMIN_DEVICE_TOKEN = '';

/**
 * Lazy initialization of Firebase Admin SDK
 */
function getMessagingClient(): Messaging | null {
  if (messagingService) {
    return messagingService;
  }

  const projectId = process.env.FIREBASE_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  const privateKey = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n');

  if (projectId && clientEmail && privateKey) {
    try {
      if (!getApps().length) {
        firebaseApp = initializeApp({
          credential: cert({
            projectId,
            clientEmail,
            privateKey,
          }),
        });
      } else {
        firebaseApp = getApps()[0];
      }

      messagingService = getMessaging(firebaseApp);
      console.log('Firebase Admin SDK inicializado com sucesso.');
      return messagingService;
    } catch (err) {
      console.error('Erro ao inicializar Firebase Admin SDK:', err);
      return null;
    }
  } else {
    // Graceful fallback when credentials are not configured yet
    return null;
  }
}

/**
 * Salva o Token FCM do dispositivo principal
 */
export function setAdminDeviceToken(token: string) {
  ADMIN_DEVICE_TOKEN = token;
}

export function getAdminDeviceToken(): string {
  return ADMIN_DEVICE_TOKEN;
}

/**
 * Função utilitária para enviar notificação Push para o seu dispositivo principal
 * Busca o token dinamicamente do banco de dados na tabela users
 */
export const sendAdminNotification = async (
  title: string, 
  body: string, 
  data: Record<string, string> = {}
) => {
  try {
    // 1. Busca no banco de dados o token do usuário administrador
    const result = await db.query(
      "SELECT fcm_token FROM users WHERE role = 'admin' AND fcm_token IS NOT NULL LIMIT 1"
    );

    const adminUser = result.rows[0];
    const targetToken = adminUser?.fcm_token || ADMIN_DEVICE_TOKEN;

    if (!targetToken) {
      console.log('Nenhum token de administrador encontrado no banco de dados.');
      return { success: false, reason: 'no_token', simulated: true };
    }

    const messaging = getMessagingClient();
    if (!messaging) {
      console.log(`[Push Notification Simulação] "${title}": "${body}" -> Token: ${targetToken} (Firebase Admin não configurado com credenciais no backend).`);
      return { success: true, simulated: true, token: targetToken };
    }

    // 2. Monta a mensagem usando o token vindo do banco
    const message = {
      notification: { title, body },
      data,
      token: targetToken,
    };

    // 3. Dispara a notificação via Firebase Admin
    const response = await messaging.send(message);
    console.log('Notificação enviada ao dispositivo principal do Admin com sucesso:', response);
    return { success: true, response };
  } catch (error) {
    console.error('Erro ao disparar notificação:', error);
    return { success: false, error };
  }
};
