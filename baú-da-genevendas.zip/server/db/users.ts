export interface DbUser {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  phone?: string;
  cityState?: string;
  fcm_token?: string | null;
  created_at: string;
  updated_at: string;
}

// In-memory persistent table state for users
const usersTable: Map<string, DbUser> = new Map([
  [
    'usr-admin-001',
    {
      id: 'usr-admin-001',
      name: 'Administrador Genevendas',
      email: 'genesisdadulce10@gmail.com',
      role: 'admin',
      phone: '924258402',
      cityState: 'Luanda, AO',
      fcm_token: null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
  ],
  [
    'usr-genesis-001',
    {
      id: 'usr-genesis-001',
      name: 'Gênesis',
      email: 'genesisdadulce10@gmail.com',
      role: 'admin',
      phone: '924258402',
      cityState: 'Luanda, AO',
      fcm_token: null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
  ],
]);

/**
 * Database abstraction query executor
 * Simulates SQL queries like `ALTER TABLE users ADD COLUMN fcm_token VARCHAR(255)`,
 * `UPDATE users SET fcm_token = $1 WHERE id = $2`,
 * and `SELECT fcm_token FROM users WHERE role = 'admin' AND fcm_token IS NOT NULL`
 */
export const db = {
  async query(sql: string, params: unknown[] = []): Promise<{ rows: any[]; rowCount: number }> {
    const trimmed = sql.trim().toUpperCase();

    // UPDATE users SET fcm_token = $1 WHERE id = $2
    if (trimmed.startsWith('UPDATE USERS SET FCM_TOKEN =')) {
      const [token, userId] = params as [string, string];
      let user = usersTable.get(userId);

      if (!user) {
        // Auto create or find by email
        user = {
          id: userId,
          name: 'Usuário',
          email: `${userId}@genevendas.com`,
          role: 'admin',
          fcm_token: token,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };
        usersTable.set(userId, user);
      } else {
        user.fcm_token = token;
        user.updated_at = new Date().toISOString();
        usersTable.set(userId, user);
      }

      return { rows: [user], rowCount: 1 };
    }

    // SELECT fcm_token FROM users WHERE role = 'admin' AND fcm_token IS NOT NULL
    if (trimmed.includes('SELECT FCM_TOKEN FROM USERS') || trimmed.includes("WHERE ROLE = 'ADMIN'")) {
      const rows = Array.from(usersTable.values())
        .filter((u) => u.role === 'admin' && Boolean(u.fcm_token))
        .map((u) => ({ fcm_token: u.fcm_token, id: u.id, email: u.email }));

      return { rows, rowCount: rows.length };
    }

    // SELECT * FROM users
    if (trimmed.startsWith('SELECT') && trimmed.includes('FROM USERS')) {
      const rows = Array.from(usersTable.values());
      return { rows, rowCount: rows.length };
    }

    return { rows: [], rowCount: 0 };
  },

  // Prisma-compatible interface
  user: {
    async update({ where, data }: { where: { id?: string; email?: string }; data: Partial<DbUser> }) {
      const targetId = where.id || (where.email ? Array.from(usersTable.values()).find((u) => u.email === where.email)?.id : null);
      if (!targetId) {
        throw new Error('Usuário não encontrado');
      }

      let user = usersTable.get(targetId);
      if (!user) {
        user = {
          id: targetId,
          name: 'Administrador',
          email: where.email || 'admin@baugenevendas.com',
          role: 'admin',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          ...data,
        };
      } else {
        user = {
          ...user,
          ...data,
          updated_at: new Date().toISOString(),
        };
      }
      usersTable.set(targetId, user);
      return user;
    },

    async findFirst({ where }: { where: { role?: string; fcm_token?: { not: null } } }) {
      const rows = Array.from(usersTable.values()).filter((u) => {
        if (where.role && u.role !== where.role) return false;
        if (where.fcm_token && !u.fcm_token) return false;
        return true;
      });
      return rows[0] || null;
    },
  },
};
