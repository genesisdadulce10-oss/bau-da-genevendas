export type ProductStatus = 'ACTIVE' | 'SOLD' | 'PAUSED';
export type ProductCondition = 'Novo' | 'Seminovo' | 'Usado';

export interface SocialLinks {
  phone?: string;
  whatsapp?: string;
  facebook?: string;
  instagram?: string;
  tiktok?: string;
  website?: string;
}

export interface ProductMedia {
  id: string;
  url: string;
  type: 'image' | 'video';
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role?: 'user' | 'admin';
  social_links?: SocialLinks;
  avatar?: string;
  rating: number;
  totalSales: number;
  cityState: string;
  verified: boolean;
  created_at: string;
}

export interface ProductImage {
  id: string;
  product_id: string;
  image_url: string;
  image_order: number;
  alt_text: string;
}

export interface Product {
  id: string;
  seller_id: string;
  seller?: User;
  title: string;
  description: string;
  price: number;
  currency?: string;
  category: string;
  condition: ProductCondition;
  status: ProductStatus;
  images: ProductImage[];
  media?: ProductMedia[];
  socialLinks?: SocialLinks;
  location: string;
  featured?: boolean;
  created_at: string;
  tags?: string[];
}

export interface ChatMessage {
  id: string;
  chatRoomId: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: string;
  isSeller: boolean;
  status?: 'sent' | 'delivered' | 'read';
}

export interface ChatRoom {
  id: string;
  productId: string;
  productTitle: string;
  productPrice: number;
  productImage: string;
  buyerId: string;
  buyerName: string;
  sellerId: string;
  sellerName: string;
  sellerPhone: string;
  messages: ChatMessage[];
  lastActivity: string;
  unreadCount: number;
}

export type ThemeMode = 'light' | 'dark' | 'high-contrast';
export type TextScale = 'normal' | 'large' | 'xlarge';
export type ColorblindMode = 'none' | 'protanopia' | 'tritanopia' | 'monochrome';

export interface AccessibilitySettings {
  theme: ThemeMode;
  textScale: TextScale;
  colorblindMode: ColorblindMode;
  soundEnabled: boolean;
  screenReaderVoice: boolean;
}

export interface CategoryInfo {
  id: string;
  name: string;
  icon: string;
  description: string;
  itemCount?: number;
}
