/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Product, 
  ProductStatus, 
  ChatRoom, 
  ChatMessage, 
  User, 
  AccessibilitySettings 
} from './types';
import { 
  CURRENT_USER, 
  INITIAL_PRODUCTS, 
  INITIAL_CHAT_ROOMS, 
  CATEGORIES 
} from './data/initialData';
import { AccessibilityBar } from './components/AccessibilityBar';
import { HeaderNav } from './components/HeaderNav';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { ChatModal } from './components/ChatModal';
import { CreateListingModal } from './components/CreateListingModal';
import { AdminPanelModal } from './components/AdminPanelModal';
import { MyListingsView } from './components/MyListingsView';
import { MessagesView } from './components/MessagesView';
import { WhatsAppDialog } from './components/WhatsAppDialog';
import { setupNotificationListener } from './services/firebaseClient';
import { playChime } from './utils/audio';
import { 
  ShoppingBag, 
  SlidersHorizontal, 
  Filter, 
  Sparkles, 
  ShieldCheck, 
  HeartHandshake, 
  Truck, 
  RotateCcw,
  CheckCircle2
} from 'lucide-react';

export default function App() {
  // Persistence in localStorage
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('genevendas_products');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return INITIAL_PRODUCTS;
      }
    }
    return INITIAL_PRODUCTS;
  });

  const [chatRooms, setChatRooms] = useState<ChatRoom[]>(() => {
    const saved = localStorage.getItem('genevendas_chat_rooms');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return INITIAL_CHAT_ROOMS;
      }
    }
    return INITIAL_CHAT_ROOMS;
  });

  const [settings, setSettings] = useState<AccessibilitySettings>(() => {
    const saved = localStorage.getItem('genevendas_a11y_settings');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return {
          theme: 'light',
          textScale: 'normal',
          colorblindMode: 'none',
          soundEnabled: true,
          screenReaderVoice: true,
        };
      }
    }
    return {
      theme: 'light',
      textScale: 'normal',
      colorblindMode: 'none',
      soundEnabled: true,
      screenReaderVoice: true,
    };
  });

  // UI Navigation & Modals State
  const [currentTab, setCurrentTab] = useState<'catalog' | 'messages' | 'my-listings'>('catalog');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterCondition, setFilterCondition] = useState<string>('all');
  const [filterSort, setFilterSort] = useState<'recent' | 'price-asc' | 'price-desc'>('recent');

  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [activeChatRoom, setActiveChatRoom] = useState<ChatRoom | null>(null);
  const [whatsAppModal, setWhatsAppModal] = useState<{ isOpen: boolean; title: string; phone: string }>({
    isOpen: false,
    title: '',
    phone: '',
  });
  const [isCreateModalOpen, setIsCreateModalOpen] = useState<boolean>(false);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState<boolean>(false);
  const [isA11yDrawerOpen, setIsA11yDrawerOpen] = useState<boolean>(false);

  // Screen reader live announcements
  const [liveAnnouncement, setLiveAnnouncement] = useState<string>('');
  const [authToken, setAuthToken] = useState<string>(() => localStorage.getItem('authToken') || '');

  // Initialize JWT Auth Token on Mount
  useEffect(() => {
    const initAuth = async () => {
      try {
        const res = await fetch('/api/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: CURRENT_USER.id,
            email: CURRENT_USER.email,
            role: CURRENT_USER.role || 'admin',
          }),
        });
        if (res.ok) {
          const data = await res.json();
          if (data.token) {
            setAuthToken(data.token);
            localStorage.setItem('authToken', data.token);
          }
        }
      } catch {
        // Fallback offline / local dev
      }
    };
    initAuth();
  }, []);

  // Listen for Real-time push notifications
  useEffect(() => {
    setupNotificationListener((payload) => {
      if (payload.title) {
        announce(`${payload.title}: ${payload.body || ''}`);
        if (settings.soundEnabled) {
          playChime('message');
        }
      }
    });
  }, [settings.soundEnabled]);

  // Persist changes
  useEffect(() => {
    localStorage.setItem('genevendas_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('genevendas_chat_rooms', JSON.stringify(chatRooms));
  }, [chatRooms]);

  useEffect(() => {
    localStorage.setItem('genevendas_a11y_settings', JSON.stringify(settings));
  }, [settings]);

  const announce = (msg: string) => {
    setLiveAnnouncement(msg);
  };

  const updateSettings = (partial: Partial<AccessibilitySettings>) => {
    setSettings((prev) => ({ ...prev, ...partial }));
  };

  // Open WhatsApp Handler
  const handleOpenWhatsApp = (product: { title: string; seller?: { phone?: string }; sellerPhone?: string }, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const phone = product.seller?.phone || (product as { sellerPhone?: string }).sellerPhone || '5511999999999';
    setWhatsAppModal({
      isOpen: true,
      title: product.title,
      phone,
    });
    announce(`Abrindo diálogo de contato via WhatsApp para o item ${product.title}`);
  };

  // Open Chat Handler
  const handleOpenChat = (product: Product, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();

    // Check if room already exists
    let existingRoom = chatRooms.find(
      (r) => r.productId === product.id && r.buyerId === CURRENT_USER.id
    );

    if (!existingRoom) {
      const newRoom: ChatRoom = {
        id: `room-${product.id}-${Date.now()}`,
        productId: product.id,
        productTitle: product.title,
        productPrice: product.price,
        productImage: product.images[0]?.image_url || 'https://images.unsplash.com/photo-1580910051074-3eb694886505?w=400',
        buyerId: CURRENT_USER.id,
        buyerName: CURRENT_USER.name,
        sellerId: product.seller_id,
        sellerName: product.seller?.name || 'Vendedor do Baú',
        sellerPhone: product.seller?.phone || '5511999999999',
        messages: [
          {
            id: `msg-${Date.now()}`,
            chatRoomId: `room-${product.id}-${Date.now()}`,
            senderId: CURRENT_USER.id,
            senderName: CURRENT_USER.name,
            text: `Olá ${product.seller?.name || 'Vendedor'}! Vi seu anúncio "${product.title}" no Baú da Genevendas e gostaria de mais informações.`,
            timestamp: new Date().toISOString(),
            isSeller: false,
            status: 'sent',
          },
        ],
        lastActivity: new Date().toISOString(),
        unreadCount: 0,
      };

      setChatRooms((prev) => [newRoom, ...prev]);
      existingRoom = newRoom;
    }

    setActiveChatRoom(existingRoom);
    if (selectedProduct) setSelectedProduct(null);
    announce(`Chat aberto com ${existingRoom.sellerName} sobre o produto ${existingRoom.productTitle}`);
  };

  // Send Message in Chat
  const handleSendMessage = (roomId: string, text: string) => {
    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      chatRoomId: roomId,
      senderId: CURRENT_USER.id,
      senderName: CURRENT_USER.name,
      text,
      timestamp: new Date().toISOString(),
      isSeller: false,
      status: 'sent',
    };

    setChatRooms((prev) =>
      prev.map((r) => {
        if (r.id === roomId) {
          return {
            ...r,
            messages: [...r.messages, newMsg],
            lastActivity: new Date().toISOString(),
          };
        }
        return r;
      })
    );

    setActiveChatRoom((prev) => {
      if (prev && prev.id === roomId) {
        return {
          ...prev,
          messages: [...prev.messages, newMsg],
        };
      }
      return prev;
    });

    // Notify backend for push notification
    try {
      fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          senderName: CURRENT_USER.name,
          roomTitle: activeChatRoom?.productTitle,
        }),
      }).catch(() => {});
    } catch {
      // Ignore
    }

    // Simulate smart real-time seller response after 1.5s
    setTimeout(() => {
      const responses = [
        'Olá! Sim, ainda está disponível. Se quiser podemos combinar a entrega ou retirada ainda hoje!',
        'Perfeito! Aceito Pix com desconto de 5% se retirar pessoalmente.',
        'Está em perfeito estado, revisado e pronto para uso.',
        'Qualquer dúvida fico à total disposição!',
      ];
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];

      const sellerMsg: ChatMessage = {
        id: `msg-seller-${Date.now()}`,
        chatRoomId: roomId,
        senderId: 'seller',
        senderName: 'Vendedor',
        text: randomResponse,
        timestamp: new Date().toISOString(),
        isSeller: true,
        status: 'delivered',
      };

      if (settings.soundEnabled) {
        playChime('message');
      }

      setChatRooms((prev) =>
        prev.map((r) => {
          if (r.id === roomId) {
            return {
              ...r,
              messages: [...r.messages, sellerMsg],
              lastActivity: new Date().toISOString(),
            };
          }
          return r;
        })
      );

      setActiveChatRoom((prev) => {
        if (prev && prev.id === roomId) {
          return {
            ...prev,
            messages: [...prev.messages, sellerMsg],
          };
        }
        return prev;
      });

      announce(`Nova mensagem recebida no chat: ${randomResponse}`);
    }, 1400);
  };

  // Create Product Handler
  const handleCreateProduct = async (newProdData: Omit<Product, 'id' | 'created_at'>) => {
    const newProduct: Product = {
      ...newProdData,
      id: `prod-${Date.now()}`,
      created_at: new Date().toISOString(),
    };

    setProducts((prev) => [newProduct, ...prev]);

    // Backend FCM Push Notification Trigger
    try {
      await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newProduct),
      });
    } catch {
      // Offline fallback
    }
  };

  // Update Status Handler
  const handleUpdateProductStatus = (productId: string, status: ProductStatus) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, status } : p))
    );
  };

  // Delete Product Handler (supports admin deletion of any product)
  const handleDeleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
  };

  const handleDeleteProductAdmin = async (productId: string) => {
    try {
      const token = authToken || localStorage.getItem('authToken');
      if (token) {
        await fetch(`/api/admin/products/${productId}`, {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
          },
        });
      }
    } catch {
      // Offline fallback
    }
    // Delete from state
    handleDeleteProduct(productId);
  };

  // Filter & Search Logic
  const filteredProducts = products.filter((prod) => {
    // Category match
    if (selectedCategory !== 'all' && prod.category !== selectedCategory) {
      return false;
    }
    // Condition match
    if (filterCondition !== 'all' && prod.condition !== filterCondition) {
      return false;
    }
    // Search query match
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const inTitle = prod.title.toLowerCase().includes(q);
      const inDesc = prod.description.toLowerCase().includes(q);
      const inLoc = prod.location.toLowerCase().includes(q);
      const inTags = prod.tags?.some((t) => t.toLowerCase().includes(q));
      if (!inTitle && !inDesc && !inLoc && !inTags) return false;
    }
    return true;
  });

  // Sorting
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (filterSort === 'price-asc') return a.price - b.price;
    if (filterSort === 'price-desc') return b.price - a.price;
    return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
  });

  const totalUnreadCount = chatRooms.reduce((sum, r) => sum + r.unreadCount, 0);

  // Theme classes
  const themeClass =
    settings.theme === 'high-contrast'
      ? 'theme-high-contrast bg-black text-yellow-300'
      : settings.theme === 'dark'
      ? 'dark bg-[#141310] text-[#FDFCFB]'
      : 'bg-[#FDFCFB] text-[#1A1A1A]';

  const fontScaleClass =
    settings.textScale === 'xlarge'
      ? 'text-lg leading-relaxed'
      : settings.textScale === 'large'
      ? 'text-base leading-relaxed'
      : 'text-sm';

  const colorblindClass =
    settings.colorblindMode === 'protanopia'
      ? 'colorblind-protanopia'
      : settings.colorblindMode === 'tritanopia'
      ? 'colorblind-tritanopia'
      : settings.colorblindMode === 'monochrome'
      ? 'colorblind-monochrome'
      : '';

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-colors duration-200 ${themeClass} ${fontScaleClass} ${colorblindClass}`}>
      {/* Live Region for Screen Readers */}
      <div
        className="sr-only"
        role="status"
        aria-live="polite"
        aria-atomic="true"
        id="a11y-live-region"
      >
        {liveAnnouncement}
      </div>

      {/* Top Accessibility Bar */}
      <AccessibilityBar
        settings={settings}
        onUpdateSettings={updateSettings}
        isOpen={isA11yDrawerOpen}
        onToggleOpen={() => setIsA11yDrawerOpen((prev) => !prev)}
        onAnnounce={announce}
      />

      {/* Main Header & Centralized Navigation */}
      <HeaderNav
        currentTab={currentTab}
        onChangeTab={(tab) => {
          setCurrentTab(tab);
          announce(`Navegando para a aba ${tab === 'catalog' ? 'Catálogo' : tab === 'messages' ? 'Mensagens' : 'Meus Anúncios'}`);
        }}
        onOpenCreateModal={() => {
          setIsCreateModalOpen(true);
          announce('Abrindo formulário de criação de anúncio');
        }}
        onOpenAdmin={() => {
          setIsAdminModalOpen(true);
          announce('Abrindo Painel de Acesso Total do Administrador');
        }}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        selectedCategory={selectedCategory}
        onSelectCategory={(cat) => {
          setSelectedCategory(cat);
          announce(`Categoria filtrada para ${cat}`);
        }}
        unreadMessagesCount={totalUnreadCount}
        theme={settings.theme}
        currentUser={CURRENT_USER}
      />

      {/* Main Centralized Body Content */}
      <main id="main-content" className="flex-1 w-full max-w-5xl mx-auto px-4 py-6 md:py-8">
        {currentTab === 'catalog' && (
          <div className="space-y-6">
            {/* Value Props & Trust Banner */}
            <section
              aria-label="Vantagens do Baú da Genevendas"
              className={`p-5 rounded-[28px] border transition-all ${
                settings.theme === 'high-contrast'
                  ? 'bg-zinc-900 border-2 border-yellow-400 text-yellow-300'
                  : 'bg-[#F5F2ED] dark:bg-[#1E1C18] border-[#E5E1DA] dark:border-[#38342D]'
              }`}
            >
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center sm:text-left">
                <div className="flex items-center gap-3.5 justify-center sm:justify-start">
                  <div className="p-3 rounded-2xl bg-white dark:bg-[#282520] text-[#5A5A40] dark:text-[#D4CEC3] border border-[#E5E1DA] dark:border-[#38342D] shadow-xs">
                    <ShieldCheck className="w-5 h-5" aria-hidden="true" />
                  </div>
                  <div>
                    <h3 className="font-serif font-bold text-sm text-[#1A1A1A] dark:text-[#FDFCFB]">
                      Compra e Venda Familiar
                    </h3>
                    <p className="text-xs text-[#8C8273] dark:text-[#A39B8B] mt-0.5">
                      Negociação direta sem taxas abusivas
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3.5 justify-center sm:justify-start">
                  <div className="p-3 rounded-2xl bg-white dark:bg-[#282520] text-[#2D5A27] dark:text-[#74BF6B] border border-[#E5E1DA] dark:border-[#38342D] shadow-xs">
                    <HeartHandshake className="w-5 h-5" aria-hidden="true" />
                  </div>
                  <div>
                    <h3 className="font-serif font-bold text-sm text-[#1A1A1A] dark:text-[#FDFCFB]">
                      Contato no WhatsApp & Chat
                    </h3>
                    <p className="text-xs text-[#8C8273] dark:text-[#A39B8B] mt-0.5">
                      Fale em tempo real com o vendedor
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3.5 justify-center sm:justify-start">
                  <div className="p-3 rounded-2xl bg-white dark:bg-[#282520] text-[#5A5A40] dark:text-[#D4CEC3] border border-[#E5E1DA] dark:border-[#38342D] shadow-xs">
                    <Sparkles className="w-5 h-5" aria-hidden="true" />
                  </div>
                  <div>
                    <h3 className="font-serif font-bold text-sm text-[#1A1A1A] dark:text-[#FDFCFB]">
                      Acessibilidade Total
                    </h3>
                    <p className="text-xs text-[#8C8273] dark:text-[#A39B8B] mt-0.5">
                      Alto contraste e leitura por voz
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* Filter and Sorting Controls Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-[24px] bg-[#F5F2ED] dark:bg-[#1E1C18] border border-[#E5E1DA] dark:border-[#38342D] shadow-xs">
              <div className="flex items-center gap-2.5 flex-wrap">
                <span className="text-xs font-bold uppercase tracking-wider text-[#8C8273] dark:text-[#A39B8B] flex items-center gap-1.5">
                  <Filter className="w-3.5 h-3.5 text-[#5A5A40] dark:text-[#A3A08A]" />
                  <span>Condição:</span>
                </span>
                <div className="flex gap-1.5">
                  {[
                    { id: 'all', label: 'Todos' },
                    { id: 'Novo', label: 'Novos' },
                    { id: 'Seminovo', label: 'Seminovos' },
                    { id: 'Usado', label: 'Usados' },
                  ].map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setFilterCondition(item.id)}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                        filterCondition === item.id
                          ? 'bg-[#5A5A40] text-white shadow-xs'
                          : 'bg-white dark:bg-[#25231E] text-[#5A5A40] dark:text-[#D4CEC3] border border-[#E5E1DA] dark:border-[#38342D] hover:bg-[#EAE5DD]'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Sort selector */}
              <div className="flex items-center gap-2">
                <label htmlFor="catalog-sort-select" className="text-xs font-bold uppercase tracking-wider text-[#8C8273] dark:text-[#A39B8B]">
                  Ordenar:
                </label>
                <select
                  id="catalog-sort-select"
                  value={filterSort}
                  onChange={(e) => setFilterSort(e.target.value as typeof filterSort)}
                  className="px-3.5 py-1.5 rounded-full text-xs font-semibold bg-white dark:bg-[#25231E] border border-[#E5E1DA] dark:border-[#38342D] text-[#1A1A1A] dark:text-[#FDFCFB] focus:ring-2 focus:ring-[#5A5A40]"
                >
                  <option value="recent">Mais Recentes</option>
                  <option value="price-asc">Menor Preço</option>
                  <option value="price-desc">Maior Preço</option>
                </select>
              </div>
            </div>

            {/* Results count & active search indicator */}
            <div className="flex items-center justify-between text-xs text-[#8C8273] dark:text-[#A39B8B] px-1 font-medium">
              <span>
                Exibindo <strong className="text-[#1A1A1A] dark:text-[#FDFCFB]">{sortedProducts.length}</strong> produtos no Baú da Genevendas
              </span>
              {searchQuery && (
                <span>
                  Resultados para: <span className="font-bold text-[#5A5A40] dark:text-[#D4CEC3]">"{searchQuery}"</span>
                </span>
              )}
            </div>

            {/* Product Card Grid */}
            {sortedProducts.length === 0 ? (
              <div className="p-12 text-center rounded-[32px] bg-[#F5F2ED] dark:bg-[#1E1C18] border border-dashed border-[#E5E1DA] dark:border-[#38342D] space-y-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-white dark:bg-[#25231E] flex items-center justify-center text-[#8C8273] border border-[#E5E1DA] dark:border-[#38342D]">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-serif font-bold text-[#1A1A1A] dark:text-[#FDFCFB]">
                  Nenhum produto encontrado com os filtros atuais
                </h3>
                <p className="text-xs text-[#8C8273] dark:text-[#A39B8B] max-w-sm mx-auto">
                  Tente alterar o termo de busca ou selecionar outra categoria para ver mais ofertas familiares.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('all');
                    setFilterCondition('all');
                  }}
                  className="px-5 py-2.5 rounded-full bg-[#5A5A40] text-white font-bold text-xs shadow-xs hover:bg-[#484833]"
                >
                  Limpar Todos os Filtros
                </button>
              </div>
            ) : (
              <div
                id="products-grid"
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6"
                role="region"
                aria-label="Grade de produtos disponíveis"
              >
                {sortedProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onSelect={(p) => setSelectedProduct(p)}
                    onOpenChat={(p, e) => handleOpenChat(p, e)}
                    onOpenWhatsApp={(p, e) => handleOpenWhatsApp(p, e)}
                    theme={settings.theme}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab: Messages / Chat */}
        {currentTab === 'messages' && (
          <MessagesView
            rooms={chatRooms}
            currentUser={CURRENT_USER}
            onSelectRoom={(room) => setActiveChatRoom(room)}
            onOpenWhatsApp={(item) => handleOpenWhatsApp(item)}
            theme={settings.theme}
          />
        )}

        {/* Tab: My Listings Management */}
        {currentTab === 'my-listings' && (
          <MyListingsView
            products={products}
            currentUserId={CURRENT_USER.id}
            onUpdateStatus={handleUpdateProductStatus}
            onDeleteProduct={handleDeleteProductAdmin}
            onSelectProduct={(p) => setSelectedProduct(p)}
            onOpenCreateModal={() => setIsCreateModalOpen(true)}
            theme={settings.theme}
            onAnnounce={announce}
            currentUser={CURRENT_USER}
          />
        )}
      </main>

      {/* Modals & Dialogs */}
      {/* Product Detail Modal */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onOpenChat={(p) => handleOpenChat(p)}
        onOpenWhatsApp={(p) => handleOpenWhatsApp(p)}
        theme={settings.theme}
        onAnnounce={announce}
        currentUser={CURRENT_USER}
        onDeleteProduct={handleDeleteProductAdmin}
      />

      {/* Real-time Internal Chat Modal */}
      <ChatModal
        room={activeChatRoom}
        currentUser={CURRENT_USER}
        onClose={() => setActiveChatRoom(null)}
        onSendMessage={handleSendMessage}
        onOpenWhatsApp={(item) => handleOpenWhatsApp(item)}
        soundEnabled={settings.soundEnabled}
        theme={settings.theme}
        onAnnounce={announce}
      />

      {/* Create Listing Modal */}
      <CreateListingModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onCreateProduct={handleCreateProduct}
        currentUser={CURRENT_USER}
        theme={settings.theme}
        onAnnounce={announce}
      />

      {/* Admin Total Control Panel Modal */}
      <AdminPanelModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
        products={products}
        onDeleteProduct={handleDeleteProductAdmin}
        onUpdateStatus={handleUpdateProductStatus}
        onSelectProduct={(p) => setSelectedProduct(p)}
        theme={settings.theme}
        onAnnounce={announce}
      />

      {/* WhatsApp Action Modal */}
      <WhatsAppDialog
        isOpen={whatsAppModal.isOpen}
        onClose={() => setWhatsAppModal((prev) => ({ ...prev, isOpen: false }))}
        productTitle={whatsAppModal.title}
        sellerPhone={whatsAppModal.phone}
        theme={settings.theme}
        onAnnounce={announce}
      />

      {/* Footer */}
      <footer
        className={`w-full mt-12 py-8 px-4 border-t transition-colors text-center text-xs ${
          settings.theme === 'high-contrast'
            ? 'bg-black text-yellow-300 border-yellow-400'
            : 'bg-[#F5F2ED] dark:bg-[#181613] text-[#8C8273] dark:text-[#A39B8B] border-[#E5E1DA] dark:border-[#38342D]'
        }`}
      >
        <div className="max-w-5xl mx-auto space-y-3">
          <p className="font-serif font-bold text-sm text-[#1A1A1A] dark:text-[#FDFCFB]">
            Baú da Genevendas • Produtos para Toda Família
          </p>
          <p className="max-w-md mx-auto leading-relaxed">
            Plataforma acessível de compra e venda local com chat em tempo real e integração direta ao WhatsApp.
          </p>
          <div className="flex justify-center items-center gap-4 pt-2 font-medium text-[11px]">
            <span>Conformidade WCAG 2.1 AA/AAA</span>
            <span>•</span>
            <span>Acessibilidade Digital</span>
            <span>•</span>
            <span>Privacidade e Segurança</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
