import React from 'react';
import { ChatRoom, User } from '../types';
import { formatPriceBRL } from '../utils/speech';
import { MessageCircle, ShieldCheck, ChevronRight, Phone } from 'lucide-react';

interface MessagesViewProps {
  rooms: ChatRoom[];
  currentUser: User;
  onSelectRoom: (room: ChatRoom) => void;
  onOpenWhatsApp: (product: { title: string; seller?: { phone: string } }) => void;
  theme: string;
}

export const MessagesView: React.FC<MessagesViewProps> = ({
  rooms,
  currentUser,
  onSelectRoom,
  onOpenWhatsApp,
  theme,
}) => {
  const isHighContrast = theme === 'high-contrast';

  return (
    <div className="space-y-4" id="messages-list-section">
      <div>
        <h2 className="text-2xl md:text-3xl font-serif text-[#141414] dark:text-[#FDFCFB]">
          Mensagens & Negociações
        </h2>
        <p className="text-sm text-[#8C8273] dark:text-[#A39B8B] mt-0.5">
          Converse em tempo real com vendedores e compradores pelo chat interno do Baú da Genevendas.
        </p>
      </div>

      {rooms.length === 0 ? (
        <div className="p-12 text-center rounded-[32px] bg-[#F5F2ED] dark:bg-[#1E1C18] border border-[#E5E1DA] dark:border-[#38342D] space-y-3">
          <div className="w-14 h-14 mx-auto rounded-full bg-white dark:bg-[#25231E] text-[#5A5A40] dark:text-[#D4CEC3] flex items-center justify-center border border-[#E5E1DA] dark:border-[#38342D]">
            <MessageCircle className="w-7 h-7" />
          </div>
          <h3 className="font-serif font-bold text-lg text-[#1A1A1A] dark:text-[#FDFCFB]">
            Nenhuma conversa ativa no momento
          </h3>
          <p className="text-xs text-[#8C8273] dark:text-[#A39B8B] max-w-sm mx-auto">
            Navegue pelos produtos no catálogo e clique em "Chat" para iniciar uma conversa com qualquer vendedor.
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {rooms.map((room) => {
            const lastMsg = room.messages[room.messages.length - 1];

            return (
              <div
                key={room.id}
                role="button"
                tabIndex={0}
                onClick={() => onSelectRoom(room)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    onSelectRoom(room);
                  }
                }}
                className={`p-4 sm:p-5 rounded-[24px] flex items-center justify-between gap-4 cursor-pointer transition-all ${
                  isHighContrast
                    ? 'bg-black text-white border-2 border-yellow-400 hover:bg-zinc-900'
                    : 'bg-white dark:bg-[#1E1C18] border border-[#E5E1DA] dark:border-[#38342D] hover:border-[#5A5A40] dark:hover:border-[#8C8273] shadow-xs'
                }`}
              >
                <div className="flex items-center gap-4 min-w-0 flex-1">
                  {/* Product thumbnail */}
                  <div className="relative shrink-0">
                    <img
                      src={room.productImage}
                      alt={room.productTitle}
                      className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl object-cover border border-[#E5E1DA] dark:border-[#38342D]"
                      referrerPolicy="no-referrer"
                    />
                    {room.unreadCount > 0 && (
                      <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-[#5A5A40] text-white rounded-full text-[10px] font-bold flex items-center justify-center shadow-xs">
                        {room.unreadCount}
                      </span>
                    )}
                  </div>

                  {/* Room Details */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5 font-bold text-sm text-[#1A1A1A] dark:text-[#FDFCFB] truncate">
                        <span>{room.sellerName}</span>
                        <ShieldCheck className="w-3.5 h-3.5 text-[#5A5A40] dark:text-[#A3A08A] shrink-0" />
                      </div>
                      <span className="text-[11px] text-[#8C8273] shrink-0">
                        {lastMsg ? new Date(lastMsg.timestamp).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : ''}
                      </span>
                    </div>

                    <p className="text-xs font-semibold text-[#2D5A27] dark:text-[#74BF6B] truncate mt-0.5">
                      {room.productTitle} • {formatPriceBRL(room.productPrice)}
                    </p>

                    <p className="text-xs text-[#8C8273] dark:text-[#A39B8B] truncate mt-0.5">
                      {lastMsg?.text || 'Iniciar conversa...'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenWhatsApp({ title: room.productTitle, seller: { phone: room.sellerPhone } });
                    }}
                    className="p-2.5 rounded-xl bg-[#25D366] hover:opacity-90 text-white transition-opacity"
                    title="Chamar no WhatsApp"
                  >
                    <Phone className="w-4 h-4 fill-white" />
                  </button>
                  <ChevronRight className="w-5 h-5 text-[#8C8273]" />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
