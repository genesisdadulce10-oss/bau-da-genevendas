import React from 'react';
import { Product } from '../types';
import { formatPriceBRL } from '../utils/speech';
import { 
  MessageCircle, 
  Phone, 
  MapPin, 
  CheckCircle2, 
  PauseCircle, 
  XCircle, 
  Sparkles,
  ChevronRight
} from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
  onOpenChat: (product: Product, e: React.MouseEvent) => void;
  onOpenWhatsApp: (product: Product, e: React.MouseEvent) => void;
  theme: string;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onSelect,
  onOpenChat,
  onOpenWhatsApp,
  theme,
}) => {
  const isHighContrast = theme === 'high-contrast';
  const mainImage = product.images[0] || {
    image_url: 'https://images.unsplash.com/photo-1580910051074-3eb694886505?w=600&auto=format&fit=crop&q=80',
    alt_text: `Foto ilustrativa do produto ${product.title}`,
  };

  const statusConfig = {
    ACTIVE: {
      label: 'Disponível',
      icon: CheckCircle2,
      bg: 'bg-emerald-100 text-emerald-900 dark:bg-emerald-950/80 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800',
    },
    PAUSED: {
      label: 'Pausado',
      icon: PauseCircle,
      bg: 'bg-amber-100 text-amber-900 dark:bg-amber-950/80 dark:text-amber-300 border-amber-300 dark:border-amber-800',
    },
    SOLD: {
      label: 'Vendido',
      icon: XCircle,
      bg: 'bg-slate-200 text-slate-900 dark:bg-slate-800 dark:text-slate-300 border-slate-400 dark:border-slate-700',
    },
  };

  const currentStatus = statusConfig[product.status] || statusConfig.ACTIVE;
  const StatusIcon = currentStatus.icon;

  return (
    <article
      id={`product-card-${product.id}`}
      tabIndex={0}
      role="button"
      aria-label={`Ver detalhes de ${product.title}, preço ${formatPriceBRL(product.price)}, condição ${product.condition}, status ${currentStatus.label}`}
      onClick={() => onSelect(product)}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onSelect(product);
        }
      }}
      className={`group relative flex flex-col rounded-[28px] overflow-hidden text-left transition-all duration-200 cursor-pointer focus:outline-none ${
        isHighContrast
          ? 'bg-black text-yellow-300 border-2 border-yellow-400 hover:bg-zinc-900'
          : 'bg-white dark:bg-[#23211D] border border-[#E5E1DA] dark:border-[#38342D] hover:border-[#D4CEC3] dark:hover:border-[#524D43] hover:shadow-md shadow-xs'
      }`}
    >
      {/* Product Image Box */}
      <div className="relative w-full aspect-[4/3] bg-[#F5F2ED] dark:bg-[#1C1A17] overflow-hidden">
        <img
          src={mainImage.image_url}
          alt={mainImage.alt_text}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          referrerPolicy="no-referrer"
        />

        {/* Condition & Status Badges */}
        <div className="absolute top-3 left-3 flex flex-wrap gap-1.5 z-10">
          <span
            className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold border shadow-xs ${currentStatus.bg}`}
          >
            <StatusIcon className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{currentStatus.label}</span>
          </span>

          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-white/90 dark:bg-[#1C1A17]/90 text-[#4A443A] dark:text-[#D4CEC3] backdrop-blur-xs border border-[#E5E1DA]/80 dark:border-[#38342D] shadow-xs">
            {product.condition}
          </span>
        </div>

        {product.featured && (
          <div className="absolute top-3 right-3 z-10">
            <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-[#5A5A40] text-white shadow-sm">
              <Sparkles className="w-3 h-3 fill-white" aria-hidden="true" />
              <span>Destaque</span>
            </span>
          </div>
        )}
      </div>

      {/* Product Content */}
      <div className="p-5 flex flex-col flex-1 justify-between gap-3">
        <div>
          {/* Location */}
          <div className="flex items-center gap-1.5 text-xs text-[#8C8273] dark:text-[#A39B8B] font-medium mb-1.5">
            <MapPin className="w-3.5 h-3.5 text-[#8C8273] shrink-0" aria-hidden="true" />
            <span className="truncate">{product.location}</span>
          </div>

          {/* Title */}
          <h3 className="font-bold text-base md:text-lg text-[#1A1A1A] dark:text-[#FDFCFB] line-clamp-2 leading-snug group-hover:text-[#5A5A40] dark:group-hover:text-[#D4CEC3] transition-colors">
            {product.title}
          </h3>

          {/* Price */}
          <div className="mt-2.5 flex items-baseline gap-2">
            <span className="text-2xl font-semibold text-[#2D5A27] dark:text-[#74BF6B] tracking-tight">
              {formatPriceBRL(product.price)}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-3 border-t border-[#E5E1DA] dark:border-[#38342D] flex items-center gap-2">
          {/* Internal Chat Button */}
          <button
            type="button"
            id={`chat-btn-${product.id}`}
            onClick={(e) => onOpenChat(product, e)}
            aria-label={`Conversar no chat interno sobre ${product.title}`}
            className={`flex-1 py-2.5 px-3 rounded-full font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
              isHighContrast
                ? 'bg-yellow-400 text-black hover:bg-yellow-300 font-black'
                : 'bg-[#F5F2ED] hover:bg-[#EAE5DD] text-[#5A5A40] dark:bg-[#2A2722] dark:hover:bg-[#343029] dark:text-[#D4CEC3] border border-[#E5E1DA] dark:border-[#38342D]'
            }`}
          >
            <MessageCircle className="w-4 h-4 text-[#5A5A40] dark:text-[#D4CEC3] shrink-0" aria-hidden="true" />
            <span>Chat</span>
          </button>

          {/* WhatsApp Direct Button */}
          <button
            type="button"
            id={`whatsapp-btn-${product.id}`}
            onClick={(e) => onOpenWhatsApp(product, e)}
            aria-label={`Falar no WhatsApp com vendedor de ${product.title}`}
            className={`flex-1 py-2.5 px-3 rounded-full font-bold text-xs flex items-center justify-center gap-1.5 transition-all text-white shadow-xs ${
              isHighContrast
                ? 'bg-emerald-400 text-black hover:bg-emerald-300 font-black'
                : 'bg-[#25D366] hover:bg-[#20ba5a] active:opacity-90'
            }`}
          >
            <Phone className="w-4 h-4 shrink-0 fill-white" aria-hidden="true" />
            <span>WhatsApp</span>
          </button>
        </div>
      </div>
    </article>
  );
};
