import React from 'react';
import { BrandLogo } from './BrandLogo';
import { CATEGORIES } from '../data/initialData';
import { User } from '../types';
import { 
  Search, 
  X, 
  ShoppingBag, 
  PlusCircle, 
  MessageCircle, 
  Package, 
  Smartphone, 
  Home, 
  Baby, 
  BookOpen, 
  Shirt, 
  Wrench,
  Sparkles,
  SlidersHorizontal,
  ShieldCheck
} from 'lucide-react';

interface HeaderNavProps {
  currentTab: 'catalog' | 'messages' | 'my-listings';
  onChangeTab: (tab: 'catalog' | 'messages' | 'my-listings') => void;
  onOpenCreateModal: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  selectedCategory: string;
  onSelectCategory: (cat: string) => void;
  unreadMessagesCount: number;
  theme: string;
  currentUser?: User;
  onOpenAdmin?: () => void;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  currentTab,
  onChangeTab,
  onOpenCreateModal,
  searchQuery,
  onSearchChange,
  selectedCategory,
  onSelectCategory,
  unreadMessagesCount,
  theme,
  currentUser,
  onOpenAdmin,
}) => {
  const isHighContrast = theme === 'high-contrast';

  const categoryIcons: Record<string, React.ReactNode> = {
    all: <ShoppingBag className="w-4 h-4" />,
    eletronicos: <Smartphone className="w-4 h-4" />,
    casa: <Home className="w-4 h-4" />,
    infantil: <Baby className="w-4 h-4" />,
    livros: <BookOpen className="w-4 h-4" />,
    moda: <Shirt className="w-4 h-4" />,
    ferramentas: <Wrench className="w-4 h-4" />,
  };

  return (
    <header
      id="main-header"
      className={`w-full transition-colors border-b ${
        isHighContrast
          ? 'bg-black border-yellow-400 text-yellow-300'
          : 'bg-[#FDFCFB]/95 dark:bg-[#1A1916]/95 border-[#E5E1DA] dark:border-[#2E2C27] backdrop-blur-md'
      }`}
    >
      {/* Centered Brand & Logo Area with Admin Status */}
      <div className="max-w-5xl mx-auto px-4 pt-5 pb-2 flex flex-col items-center justify-center text-center relative">
        <button
          type="button"
          onClick={() => onChangeTab('catalog')}
          aria-label="Ir para a página inicial do Baú da Genevendas"
          className="focus:outline-none focus:ring-4 focus:ring-[#5A5A40] rounded-2xl p-1 transition-transform active:scale-95"
        >
          <BrandLogo size="banner" />
        </button>

        {currentUser?.role === 'admin' && (
          <div className="mt-1 flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-[#5A5A40]/10 dark:bg-[#5A5A40]/30 border border-[#5A5A40]/30 text-[#5A5A40] dark:text-[#D4CEC3] text-[11px] font-bold">
            <ShieldCheck className="w-3.5 h-3.5 text-[#5A5A40] dark:text-[#D4CEC3]" aria-hidden="true" />
            <span>Modo Superusuário: Administrador</span>
          </div>
        )}
      </div>

      {/* Main Action Bar (Search & Navigation Tabs) */}
      <div className="max-w-5xl mx-auto px-4 py-3 flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Search Bar */}
        <div className="w-full md:max-w-md relative">
          <label htmlFor="catalog-search-input" className="sr-only">
            Buscar produtos no Baú da Genevendas
          </label>
          <div className="relative flex items-center">
            <Search
              className="absolute left-3.5 w-4 h-4 text-[#8C8273] dark:text-[#A39B8B] pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="text"
              id="catalog-search-input"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Buscar produtos, celulares, móveis..."
              className="w-full pl-10 pr-9 py-2.5 rounded-full bg-[#F5F2ED] dark:bg-[#25231E] border border-[#E5E1DA] dark:border-[#38342D] text-[#1A1A1A] dark:text-[#EAE5DD] placeholder-[#8C8273] text-sm focus:outline-none focus:ring-2 focus:ring-[#5A5A40] transition-all"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                aria-label="Limpar texto da busca"
                className="absolute right-3 p-1 rounded-full text-[#8C8273] hover:text-[#1A1A1A] dark:hover:text-[#FDFCFB]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav
          className="flex items-center justify-center flex-wrap gap-2 w-full md:w-auto"
          aria-label="Menu principal de navegação"
        >
          {/* Catalog Tab */}
          <button
            type="button"
            id="nav-tab-catalog"
            onClick={() => onChangeTab('catalog')}
            aria-current={currentTab === 'catalog' ? 'page' : undefined}
            className={`px-4 py-2.5 rounded-full font-bold text-xs sm:text-sm flex items-center gap-2 transition-all ${
              currentTab === 'catalog'
                ? isHighContrast
                  ? 'bg-yellow-400 text-black border-2 border-yellow-500 font-black'
                  : 'bg-[#5A5A40] text-white shadow-sm'
                : 'bg-[#F5F2ED] dark:bg-[#25231E] text-[#4A443A] dark:text-[#D4CEC3] hover:bg-[#EAE5DD] dark:hover:bg-[#322F29]'
            }`}
          >
            <ShoppingBag className="w-4 h-4" aria-hidden="true" />
            <span>Catálogo</span>
          </button>

          {/* Messages Tab */}
          <button
            type="button"
            id="nav-tab-messages"
            onClick={() => onChangeTab('messages')}
            aria-current={currentTab === 'messages' ? 'page' : undefined}
            className={`relative px-4 py-2.5 rounded-full font-bold text-xs sm:text-sm flex items-center gap-2 transition-all ${
              currentTab === 'messages'
                ? isHighContrast
                  ? 'bg-yellow-400 text-black border-2 border-yellow-500 font-black'
                  : 'bg-[#5A5A40] text-white shadow-sm'
                : 'bg-[#F5F2ED] dark:bg-[#25231E] text-[#4A443A] dark:text-[#D4CEC3] hover:bg-[#EAE5DD] dark:hover:bg-[#322F29]'
            }`}
          >
            <MessageCircle className="w-4 h-4" aria-hidden="true" />
            <span>Chat</span>
            {unreadMessagesCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-[#5A5A40] text-white text-[10px] font-black border border-[#FDFCFB]">
                {unreadMessagesCount}
              </span>
            )}
          </button>

          {/* My Listings Tab */}
          <button
            type="button"
            id="nav-tab-my-listings"
            onClick={() => onChangeTab('my-listings')}
            aria-current={currentTab === 'my-listings' ? 'page' : undefined}
            className={`px-4 py-2.5 rounded-full font-bold text-xs sm:text-sm flex items-center gap-2 transition-all ${
              currentTab === 'my-listings'
                ? isHighContrast
                  ? 'bg-yellow-400 text-black border-2 border-yellow-500 font-black'
                  : 'bg-[#5A5A40] text-white shadow-sm'
                : 'bg-[#F5F2ED] dark:bg-[#25231E] text-[#4A443A] dark:text-[#D4CEC3] hover:bg-[#EAE5DD] dark:hover:bg-[#322F29]'
            }`}
          >
            <Package className="w-4 h-4" aria-hidden="true" />
            <span>Meus Anúncios</span>
          </button>

          {/* Admin Panel Button: only displayed if role is admin */}
          {currentUser?.role === 'admin' && onOpenAdmin && (
            <button
              type="button"
              id="header-admin-panel-btn"
              onClick={onOpenAdmin}
              className="flex items-center gap-1.5 bg-red-600 text-white px-3.5 py-2 rounded-full text-xs font-semibold hover:bg-red-700 active:scale-95 transition-all shadow-sm border border-red-700"
              title="Painel de Controle Total (Admin)"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Painel Admin</span>
            </button>
          )}

          {/* Primary Call-to-action: Anunciar Produto */}
          <button
            type="button"
            id="header-create-product-btn"
            onClick={onOpenCreateModal}
            className={`px-5 py-2.5 rounded-full font-bold text-xs sm:text-sm flex items-center gap-2 transition-all text-white shadow-sm ${
              isHighContrast
                ? 'bg-yellow-400 text-black hover:bg-yellow-300'
                : 'bg-[#5A5A40] hover:bg-[#484833] active:scale-98'
            }`}
          >
            <PlusCircle className="w-4 h-4" aria-hidden="true" />
            <span>+ Anunciar</span>
          </button>
        </nav>
      </div>

      {/* Category Pills (Visible when in catalog tab) */}
      {currentTab === 'catalog' && (
        <div className="border-t border-[#E5E1DA] dark:border-[#2E2C27] bg-[#F5F2ED]/60 dark:bg-[#1E1C18]/60 py-2.5 px-4 overflow-x-auto">
          <div
            className="max-w-5xl mx-auto flex items-center gap-2 scrollbar-none"
            role="tablist"
            aria-label="Categorias de produtos"
          >
            {CATEGORIES.map((cat) => {
              const isSelected = selectedCategory === cat.id;

              return (
                <button
                  key={cat.id}
                  id={`cat-pill-${cat.id}`}
                  type="button"
                  role="tab"
                  aria-selected={isSelected}
                  onClick={() => onSelectCategory(cat.id)}
                  className={`px-4 py-1.5 rounded-full text-xs font-semibold flex items-center gap-2 shrink-0 transition-all border ${
                    isSelected
                      ? isHighContrast
                        ? 'bg-yellow-400 text-black border-yellow-500 font-black'
                        : 'bg-[#5A5A40] text-white border-[#5A5A40] shadow-xs'
                      : 'bg-white dark:bg-[#25231E] text-[#4A443A] dark:text-[#D4CEC3] border-[#E5E1DA] dark:border-[#38342D] hover:bg-[#F5F2ED] dark:hover:bg-[#2E2A24]'
                  }`}
                >
                  <span className="shrink-0">{categoryIcons[cat.id] || <ShoppingBag className="w-3.5 h-3.5" />}</span>
                  <span>{cat.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
};
