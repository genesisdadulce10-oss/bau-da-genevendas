import React, { useState } from 'react';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'banner';
  className?: string;
  showSubtitle?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  size = 'md',
  className = '',
}) => {
  const [currentSrc, setCurrentSrc] = useState<string>('/Gemini_Generated_Image_fto41ifto41ifto4.png');
  const [hasError, setHasError] = useState<boolean>(false);

  const handleError = () => {
    if (currentSrc === '/Gemini_Generated_Image_fto41ifto41ifto4.png') {
      setCurrentSrc('/logo.svg');
    } else {
      setHasError(true);
    }
  };

  const sizeClasses = {
    sm: 'h-10 max-w-[200px]',
    md: 'h-14 max-w-[280px] md:h-18 md:max-w-[340px]',
    lg: 'h-20 max-w-[380px] md:h-28 md:max-w-[460px]',
    banner: 'h-24 max-w-[420px] md:h-36 md:max-w-[560px] w-auto',
  };

  if (!hasError) {
    return (
      <div className={`flex flex-col items-center justify-center ${className}`}>
        <img
          src={currentSrc}
          alt="Logotipo oficial Baú da Genevendas - Produtos para Toda Família"
          className={`object-contain transition-all duration-300 drop-shadow-sm ${sizeClasses[size]}`}
          onError={handleError}
          referrerPolicy="no-referrer"
          id="main-app-brand-logo"
        />
      </div>
    );
  }

  return (
    <div
      id="brand-logo-fallback"
      className={`inline-flex items-center gap-3 select-none ${className}`}
      aria-label="Baú da Genevendas - Produtos para Toda Família"
    >
      <div className="flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-br from-teal-500 to-sky-600 text-white shadow-md">
        <span className="font-black text-2xl">G</span>
      </div>
      <div className="text-left">
        <div className="font-extrabold tracking-tight text-teal-900 dark:text-teal-200 leading-none text-xl">
          BAÚ DA <span className="text-teal-600 dark:text-teal-400">GENEVENDAS</span>
        </div>
        <p className="text-[11px] font-semibold tracking-wider uppercase text-slate-500 dark:text-slate-400 mt-1">
          Produtos para Toda Família
        </p>
      </div>
    </div>
  );
};

