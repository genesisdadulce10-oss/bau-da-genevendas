import React, { useState } from 'react';
import { Product } from '../types';
import { 
  X, 
  Smartphone, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  ShieldCheck, 
  Flame, 
  Crown,
  Loader2,
  Phone
} from 'lucide-react';

interface ExpressPaymentModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAnnounce: (msg: string) => void;
  onSuccessBoost?: (productId: string, plan: 'STANDARD' | 'VIP') => void;
}

export const ExpressPaymentModal: React.FC<ExpressPaymentModalProps> = ({
  product,
  isOpen,
  onClose,
  onAnnounce,
  onSuccessBoost,
}) => {
  const [selectedPlan, setSelectedPlan] = useState<'STANDARD' | 'VIP'>('STANDARD');
  const [customerPhone, setCustomerPhone] = useState('924258402');
  const [loading, setLoading] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<{
    success?: boolean;
    message?: string;
    reference?: string;
    instructions?: string;
  } | null>(null);

  if (!isOpen || !product) return null;

  const planAmount = selectedPlan === 'STANDARD' ? 1000 : 10500;
  const planDays = selectedPlan === 'STANDARD' ? 7 : 30;

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerPhone || customerPhone.trim().length < 9) {
      alert('Por favor insira um número de telefone Multicaixa Express válido com 9 dígitos.');
      return;
    }

    setLoading(true);
    setPaymentStatus(null);
    onAnnounce('Enviando solicitação de pagamento para o Multicaixa Express...');

    try {
      const response = await fetch('/api/payments/checkout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: planAmount,
          customerPhone: customerPhone.trim(),
          duration: planDays,
          productId: product.id,
        }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setPaymentStatus({
          success: true,
          message: data.message || 'Solicitação de pagamento enviada para o seu Express!',
          reference: data.data?.reference || `EXP-${Math.floor(100000 + Math.random() * 900000)}`,
          instructions: data.data?.instructions || 'Abra o aplicativo Multicaixa Express no seu celular e confirme a autorização de débito.',
        });
        onAnnounce('Cobrança enviada com sucesso para o Multicaixa Express!');
        if (onSuccessBoost) {
          onSuccessBoost(product.id, selectedPlan);
        }
      } else {
        setPaymentStatus({
          success: false,
          message: data.message || 'Falha ao processar pagamento Express. Tente novamente.',
        });
        onAnnounce('Erro ao gerar cobrança Express.');
      }
    } catch (err) {
      console.error('Erro na requisição:', err);
      setPaymentStatus({
        success: false,
        message: 'Erro de conexão ao comunicar com a gateway de pagamento.',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in"
      role="dialog"
      aria-modal="true"
      aria-labelledby="express-payment-title"
    >
      <div className="bg-white dark:bg-[#201E1A] rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-[#E5E1DA] dark:border-[#38342D] relative overflow-hidden">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 rounded-full transition-colors"
          aria-label="Fechar modal de pagamento"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 dark:bg-amber-400/10 flex items-center justify-center text-amber-600 dark:text-amber-400">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <h3 id="express-payment-title" className="text-xl font-bold font-serif text-[#141414] dark:text-[#FDFCFB]">
              Destacar Anúncio Express
            </h3>
            <p className="text-xs text-[#8C8273] dark:text-[#A39B8B]">
              Receba até 5x mais contatos no WhatsApp com destaque no topo.
            </p>
          </div>
        </div>

        {/* Product Preview Snippet */}
        <div className="bg-[#F8F6F2] dark:bg-[#282622] rounded-2xl p-3.5 mb-6 flex items-center gap-3 border border-[#EBE7DF] dark:border-[#3A3630]">
          <img 
            src={product.images?.[0]?.image_url || 'https://images.unsplash.com/photo-1580910051074-3eb694886505?w=200'} 
            alt={product.title}
            className="w-12 h-12 rounded-xl object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="min-w-0 flex-1">
            <h4 className="text-sm font-semibold text-[#141414] dark:text-[#FDFCFB] truncate">
              {product.title}
            </h4>
            <span className="text-xs font-bold text-[#2D5A27] dark:text-[#74BF6B]">
              {product.price.toLocaleString('pt-AO')} Kz
            </span>
          </div>
        </div>

        {paymentStatus ? (
          /* Payment Result Card */
          <div className="space-y-4">
            <div className={`p-5 rounded-2xl border ${
              paymentStatus.success 
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200' 
                : 'bg-red-50 dark:bg-red-950/40 border-red-300 dark:border-red-800 text-red-900 dark:text-red-200'
            }`}>
              <div className="flex items-center gap-2.5 mb-2">
                {paymentStatus.success ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 shrink-0" />
                )}
                <span className="font-bold text-sm">
                  {paymentStatus.success ? 'Solicitação Express Emitida!' : 'Não foi possível processar'}
                </span>
              </div>
              <p className="text-xs leading-relaxed opacity-90">
                {paymentStatus.message}
              </p>
              {paymentStatus.reference && (
                <div className="mt-3 pt-3 border-t border-emerald-200 dark:border-emerald-800/60 flex items-center justify-between text-xs">
                  <span className="font-semibold">Referência:</span>
                  <span className="font-mono font-bold bg-white dark:bg-black/30 px-2 py-0.5 rounded-sm">
                    {paymentStatus.reference}
                  </span>
                </div>
              )}
            </div>

            {paymentStatus.instructions && (
              <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 rounded-2xl p-4 text-xs text-amber-900 dark:text-amber-200">
                <p className="font-semibold mb-1">📱 Próximo passo no seu telemóvel:</p>
                <p className="text-[11px] leading-relaxed">{paymentStatus.instructions}</p>
              </div>
            )}

            <button
              onClick={onClose}
              className="w-full py-3.5 rounded-2xl bg-[#5A5A40] text-white font-bold text-sm hover:opacity-90 transition-opacity"
            >
              Concluir e Voltar
            </button>
          </div>
        ) : (
          /* Payment Form */
          <form onSubmit={handleCheckout} className="space-y-5">
            {/* Plan Selector */}
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setSelectedPlan('STANDARD')}
                className={`p-4 rounded-2xl border text-left transition-all relative ${
                  selectedPlan === 'STANDARD'
                    ? 'border-amber-600 bg-amber-50/70 dark:bg-amber-950/30 text-amber-900 dark:text-amber-200 ring-2 ring-amber-500/20'
                    : 'border-[#E5E1DA] dark:border-[#38342D] hover:bg-[#FAF8F5] dark:hover:bg-[#282622] text-[#141414] dark:text-[#FDFCFB]'
                }`}
              >
                <div className="flex items-center gap-1.5 mb-1.5">
                  <Flame className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                  <span className="font-bold text-xs uppercase tracking-wide">Destaque</span>
                </div>
                <div className="text-lg font-bold text-[#2D5A27] dark:text-[#74BF6B]">
                  1.000 Kz
                </div>
                <div className="text-[11px] text-[#8C8273] dark:text-[#A39B8B] mt-0.5">
                  Válido por 7 dias
                </div>
              </button>

              <button
                type="button"
                onClick={() => setSelectedPlan('VIP')}
                className={`p-4 rounded-2xl border text-left transition-all relative ${
                  selectedPlan === 'VIP'
                    ? 'border-amber-600 bg-amber-50/70 dark:bg-amber-950/30 text-amber-900 dark:text-amber-200 ring-2 ring-amber-500/20'
                    : 'border-[#E5E1DA] dark:border-[#38342D] hover:bg-[#FAF8F5] dark:hover:bg-[#282622] text-[#141414] dark:text-[#FDFCFB]'
                }`}
              >
                <div className="flex items-center gap-1.5 mb-1.5">
                  <Crown className="w-4 h-4 text-amber-500" />
                  <span className="font-bold text-xs uppercase tracking-wide">Super VIP</span>
                </div>
                <div className="text-lg font-bold text-[#2D5A27] dark:text-[#74BF6B]">
                  10.500 Kz
                </div>
                <div className="text-[11px] text-[#8C8273] dark:text-[#A39B8B] mt-0.5">
                  Válido por 30 dias
                </div>
              </button>
            </div>

            {/* Phone Input */}
            <div>
              <label htmlFor="customer-phone-input" className="block text-xs font-bold text-[#141414] dark:text-[#FDFCFB] mb-2 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-stone-500" />
                Número do seu Multicaixa Express
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xs font-bold text-stone-400">
                  +244
                </span>
                <input
                  id="customer-phone-input"
                  type="tel"
                  maxLength={9}
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder="924 258 402"
                  className="w-full pl-14 pr-4 py-3 rounded-2xl border border-[#D8D3C8] dark:border-[#403B32] bg-white dark:bg-[#1C1A17] text-base font-semibold text-[#141414] dark:text-[#FDFCFB] focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                  required
                />
              </div>
              <p className="text-[11px] text-[#8C8273] dark:text-[#A39B8B] mt-1.5">
                O valor de <strong>{planAmount.toLocaleString('pt-AO')} Kz</strong> será debitado automaticamente via notificação Express.
              </p>
            </div>

            {/* Security Guarantee */}
            <div className="flex items-center gap-2 text-xs text-stone-500 dark:text-stone-400 bg-stone-50 dark:bg-stone-900/50 p-3 rounded-xl border border-stone-200 dark:border-stone-800">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Transação protegida e auditada pela rede EMIS Multicaixa.</span>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 rounded-2xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Enviando cobrança ao Express...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Pagar {planAmount.toLocaleString('pt-AO')} Kz com Express</span>
                </>
              )}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
