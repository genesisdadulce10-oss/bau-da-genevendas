import React, { useState, useEffect, useRef } from 'react';
import { ChatRoom, ChatMessage, Product, User } from '../types';
import { formatPriceBRL } from '../utils/speech';
import { playChime } from '../utils/audio';
import { 
  X, 
  Send, 
  Phone, 
  Check, 
  CheckCheck, 
  Sparkles, 
  Info,
  Smile,
  ShieldCheck,
  Bot
} from 'lucide-react';

interface ChatModalProps {
  room: ChatRoom | null;
  currentUser: User;
  onClose: () => void;
  onSendMessage: (roomId: string, text: string) => void;
  onOpenWhatsApp: (product: { title: string; seller?: { phone: string } }) => void;
  soundEnabled: boolean;
  theme: string;
  onAnnounce: (msg: string) => void;
}

export const ChatModal: React.FC<ChatModalProps> = ({
  room,
  currentUser,
  onClose,
  onSendMessage,
  onOpenWhatsApp,
  soundEnabled,
  theme,
  onAnnounce,
}) => {
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const isHighContrast = theme === 'high-contrast';

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [room?.messages, isTyping]);

  useEffect(() => {
    // Focus input on open
    setTimeout(() => {
      inputRef.current?.focus();
    }, 150);
  }, [room?.id]);

  if (!room) return null;

  const handleSend = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanText = inputText.trim();
    if (!cleanText) return;

    if (soundEnabled) {
      playChime('click');
    }

    onSendMessage(room.id, cleanText);
    setInputText('');
    onAnnounce(`Mensagem enviada: ${cleanText}`);

    // Focus back on input
    inputRef.current?.focus();
  };

  const quickPrompts = [
    'Olá! Ainda está disponível?',
    'Aceita pagamento à vista via Pix?',
    'Em qual região podemos combinar a retirada?',
    'O valor é negociável?',
  ];

  return (
    <div
      className="fixed inset-0 z-50 overflow-hidden bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="chat-room-title"
      id="chat-modal-container"
    >
      <div
        className={`relative w-full max-w-2xl h-[92vh] sm:h-[85vh] flex flex-col rounded-[32px] overflow-hidden shadow-2xl transition-all ${
          isHighContrast
            ? 'bg-black text-white border-4 border-yellow-400'
            : 'bg-[#FDFCFB] dark:bg-[#1E1C18] text-[#1A1A1A] dark:text-[#FDFCFB] border border-[#E5E1DA] dark:border-[#38342D]'
        }`}
      >
        {/* Chat Top Header */}
        <div className="px-5 py-4 border-b border-[#E5E1DA] dark:border-[#38342D] bg-[#F5F2ED] dark:bg-[#181613] flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-[#5A5A40] text-white font-bold flex items-center justify-center text-sm shadow-xs">
                {room.sellerName.charAt(0)}
              </div>
              <span className="absolute bottom-0 right-0 w-3 h-3 bg-[#2D5A27] border-2 border-white dark:border-[#1E1C18] rounded-full" title="Online no chat" />
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-1.5 font-bold text-sm sm:text-base text-[#1A1A1A] dark:text-[#FDFCFB] truncate">
                <span id="chat-room-title">{room.sellerName}</span>
                <ShieldCheck className="w-4 h-4 text-[#5A5A40] dark:text-[#A3A08A] shrink-0" aria-label="Vendedor Verificado" />
              </div>
              <p className="text-xs text-[#2D5A27] dark:text-[#74BF6B] font-medium">
                Conectado em tempo real
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Direct WhatsApp shortcut button */}
            <button
              type="button"
              onClick={() => onOpenWhatsApp({ title: room.productTitle, seller: { phone: room.sellerPhone } })}
              aria-label="Abrir conversa no WhatsApp"
              className="px-3 py-1.5 rounded-full bg-[#25D366] hover:opacity-90 text-white transition-opacity flex items-center gap-1.5 text-xs font-bold shadow-xs"
              title="Abrir no WhatsApp"
            >
              <Phone className="w-3.5 h-3.5 fill-white" aria-hidden="true" />
              <span className="hidden sm:inline">WhatsApp</span>
            </button>

            {/* Close button */}
            <button
              type="button"
              id="close-chat-btn"
              onClick={onClose}
              aria-label="Fechar janela de chat"
              className="w-9 h-9 rounded-full hover:bg-[#EAE5DD] dark:hover:bg-[#2A2722] flex items-center justify-center transition-colors text-[#8C8273] dark:text-[#D4CEC3]"
            >
              <X className="w-5 h-5" aria-hidden="true" />
            </button>
          </div>
        </div>

        {/* Product context banner */}
        <div className="px-5 py-2.5 bg-[#F5F2ED]/80 dark:bg-[#25231E]/80 border-b border-[#E5E1DA] dark:border-[#38342D] flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5 min-w-0">
            <img
              src={room.productImage}
              alt={room.productTitle}
              className="w-10 h-10 rounded-xl object-cover border border-[#E5E1DA] dark:border-[#38342D] shrink-0"
              referrerPolicy="no-referrer"
            />
            <div className="min-w-0">
              <span className="font-medium text-[#1A1A1A] dark:text-[#FDFCFB] block truncate">
                {room.productTitle}
              </span>
              <span className="font-bold text-[#2D5A27] dark:text-[#74BF6B]">
                {formatPriceBRL(room.productPrice)}
              </span>
            </div>
          </div>
          <span className="px-3 py-1 rounded-full bg-white dark:bg-[#1E1C18] text-[#5A5A40] dark:text-[#D4CEC3] border border-[#E5E1DA] dark:border-[#38342D] font-medium text-[11px] shrink-0">
            Negociação Segura
          </span>
        </div>

        {/* Message Thread */}
        <div
          className="flex-1 p-5 overflow-y-auto space-y-3 bg-[#FDFCFB] dark:bg-[#141311]"
          role="log"
          aria-live="polite"
          aria-label="Mensagens do chat"
        >
          <div className="text-center my-2">
            <span className="px-3.5 py-1 rounded-full text-[11px] font-medium bg-[#F5F2ED] dark:bg-[#25231E] text-[#8C8273] dark:text-[#A39B8B] border border-[#E5E1DA] dark:border-[#38342D]">
              Início da conversa sobre este item
            </span>
          </div>

          {room.messages.map((msg) => {
            const isMe = msg.senderId === currentUser.id;

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[82%] sm:max-w-[75%] px-4 py-3 rounded-2xl text-sm leading-relaxed shadow-xs ${
                    isMe
                      ? isHighContrast
                        ? 'bg-yellow-400 text-black font-bold rounded-tr-xs border border-yellow-500'
                        : 'bg-[#5A5A40] text-white rounded-tr-xs'
                      : isHighContrast
                      ? 'bg-zinc-800 text-white rounded-tl-xs border border-zinc-700'
                      : 'bg-white dark:bg-[#25231E] text-[#1A1A1A] dark:text-[#FDFCFB] rounded-tl-xs border border-[#E5E1DA] dark:border-[#38342D]'
                  }`}
                >
                  <p className="whitespace-pre-line">{msg.text}</p>
                </div>
                <div className="flex items-center gap-1 text-[10px] text-[#8C8273] dark:text-[#A39B8B] mt-1 px-1 font-medium">
                  <span>
                    {new Date(msg.timestamp).toLocaleTimeString('pt-BR', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                  {isMe && (
                    <CheckCheck className="w-3.5 h-3.5 text-[#5A5A40] dark:text-[#A3A08A]" aria-label="Mensagem entregue e lida" />
                  )}
                </div>
              </div>
            );
          })}

          {isTyping && (
            <div className="flex items-center gap-2 text-xs text-[#8C8273] dark:text-[#A39B8B] italic">
              <Bot className="w-3.5 h-3.5 animate-bounce text-[#5A5A40]" />
              <span>{room.sellerName} está digitando...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Pills */}
        <div className="px-4 py-2 bg-[#F5F2ED] dark:bg-[#181613] border-t border-[#E5E1DA] dark:border-[#38342D] overflow-x-auto flex gap-2">
          {quickPrompts.map((prompt, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => {
                setInputText(prompt);
                inputRef.current?.focus();
              }}
              className="px-3.5 py-1 rounded-full text-xs font-medium bg-white dark:bg-[#25231E] hover:bg-[#EAE5DD] text-[#5A5A40] dark:text-[#D4CEC3] border border-[#E5E1DA] dark:border-[#38342D] transition-colors shrink-0 whitespace-nowrap"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Input Form */}
        <form
          onSubmit={handleSend}
          className="p-4 bg-white dark:bg-[#1E1C18] border-t border-[#E5E1DA] dark:border-[#38342D] flex items-center gap-2"
        >
          <input
            ref={inputRef}
            type="text"
            id="chat-message-input"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Escreva sua mensagem para o vendedor..."
            aria-label="Campo de texto para digitar mensagem do chat"
            className="flex-1 px-4 py-3 rounded-full bg-[#F5F2ED] dark:bg-[#25231E] border border-[#E5E1DA] dark:border-[#38342D] text-[#1A1A1A] dark:text-[#FDFCFB] placeholder-[#8C8273] text-sm focus:outline-none focus:ring-2 focus:ring-[#5A5A40]"
          />

          <button
            type="submit"
            id="send-chat-message-btn"
            disabled={!inputText.trim()}
            aria-label="Enviar mensagem"
            className={`w-11 h-11 rounded-full font-bold transition-all flex items-center justify-center shrink-0 ${
              inputText.trim()
                ? isHighContrast
                  ? 'bg-yellow-400 text-black hover:bg-yellow-300'
                  : 'bg-[#5A5A40] hover:bg-[#484833] text-white shadow-xs'
                : 'bg-[#E5E1DA] dark:bg-[#2A2722] text-[#8C8273] cursor-not-allowed'
            }`}
          >
            <Send className="w-4 h-4" aria-hidden="true" />
          </button>
        </form>
      </div>
    </div>
  );
};
