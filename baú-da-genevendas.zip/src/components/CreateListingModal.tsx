import React, { useState } from 'react';
import { Product, ProductCondition, ProductMedia, SocialLinks, User } from '../types';
import { playChime } from '../utils/audio';
import { 
  X, 
  Plus, 
  Trash2, 
  Upload, 
  Video as VideoIcon, 
  Image as ImageIcon, 
  Phone, 
  MessageCircle, 
  Instagram, 
  Facebook, 
  Sparkles, 
  AlertCircle,
  Check,
  Share2
} from 'lucide-react';

interface CreateListingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateProduct: (product: Omit<Product, 'id' | 'created_at'>) => void;
  currentUser: User;
  theme: string;
  onAnnounce: (msg: string) => void;
}

export const CreateListingModal: React.FC<CreateListingModalProps> = ({
  isOpen,
  onClose,
  onCreateProduct,
  currentUser,
  theme,
  onAnnounce,
}) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState('eletronicos');
  const [condition, setCondition] = useState<ProductCondition>('Seminovo');
  const [location, setLocation] = useState(currentUser.cityState || 'Luanda, Angola');

  // Contactos e redes sociais do vendedor
  const [phone, setPhone] = useState(currentUser.phone || '924258402');
  const [whatsapp, setWhatsapp] = useState(currentUser.phone || '924258402');
  const [instagram, setInstagram] = useState('');
  const [facebook, setFacebook] = useState('');
  const [tiktok, setTiktok] = useState('');

  // Media (Fotos e Vídeos da Galeria)
  const [mediaList, setMediaList] = useState<ProductMedia[]>([
    {
      id: 'media-initial-1',
      url: 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=800&auto=format&fit=crop&q=80',
      type: 'image',
    },
  ]);
  const [urlInput, setUrlInput] = useState('');
  const [urlType, setUrlType] = useState<'image' | 'video'>('image');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const isHighContrast = theme === 'high-contrast';

  // Carregar ficheiros diretamente da galeria do aparelho (Imagens e Vídeos)
  const handleMediaFilesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const selectedFiles = Array.from(e.target.files) as File[];
      const newItems: ProductMedia[] = selectedFiles.map((file: File, idx: number) => ({
        id: `media-upload-${Date.now()}-${idx}`,
        url: URL.createObjectURL(file),
        type: file.type.startsWith('video/') ? ('video' as const) : ('image' as const),
      }));

      setMediaList((prev) => [...prev, ...newItems]);
      onAnnounce(`${newItems.length} arquivos carregados da galeria do aparelho.`);
    }
  };

  const handleAddMediaUrl = () => {
    if (!urlInput.trim()) return;
    setMediaList((prev) => [
      ...prev,
      {
        id: `media-url-${Date.now()}`,
        url: urlInput.trim(),
        type: urlType,
      },
    ]);
    setUrlInput('');
    onAnnounce('Nova mídia adicionada.');
  };

  const handleRemoveMedia = (id: string) => {
    setMediaList((prev) => prev.filter((m) => m.id !== id));
    onAnnounce('Item de mídia removido.');
  };

  const applyTemplate = (type: 'smartphone' | 'sofa' | 'brinquedo' | 'cozinha') => {
    const templates = {
      smartphone: {
        title: 'Smartphone Xiaomi Redmi Note 13 256GB',
        description: 'Smartphone novo na caixa lacrada, 256GB de memória, câmera de 108MP e bateria de 5000mAh. Acompanha carregador turbo original e película de proteção instalada.',
        price: '185000',
        category: 'eletronicos',
        condition: 'Novo' as ProductCondition,
        media: [
          { id: 't1', url: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=800&auto=format&fit=crop&q=80', type: 'image' as const },
        ],
      },
      sofa: {
        title: 'Mesa de Jantar Madeira Maciça com 4 Cadeiras',
        description: 'Conjunto completo de mesa e 4 cadeiras estofadas em linho. Madeira nobre impermeabilizada, perfeita para sala de jantar familiar. Estado impecável.',
        price: '120000',
        category: 'casa',
        condition: 'Seminovo' as ProductCondition,
        media: [
          { id: 't2', url: 'https://images.unsplash.com/photo-1617806118233-18e1de247200?w=800&auto=format&fit=crop&q=80', type: 'image' as const },
        ],
      },
      brinquedo: {
        title: 'Bicicleta Infantil Aro 16 com Rodinhas Removíveis',
        description: 'Bicicleta infantil super resistente com freios macios, protetor de corrente integral e cestinha frontal. Pouquíssimo usada.',
        price: '45000',
        category: 'infantil',
        condition: 'Seminovo' as ProductCondition,
        media: [
          { id: 't3', url: 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=800&auto=format&fit=crop&q=80', type: 'image' as const },
        ],
      },
      cozinha: {
        title: 'Fritadeira Elétrica Air Fryer Digital 4L',
        description: 'Air fryer digital com 8 funções pré-programadas, cesto antiaderente removível de fácil limpeza e timer de até 60 minutos.',
        price: '38000',
        category: 'casa',
        condition: 'Seminovo' as ProductCondition,
        media: [
          { id: 't4', url: 'https://images.unsplash.com/photo-1584990347449-3991206f47df?w=800&auto=format&fit=crop&q=80', type: 'image' as const },
        ],
      },
    };

    const sel = templates[type];
    setTitle(sel.title);
    setDescription(sel.description);
    setPrice(sel.price);
    setCategory(sel.category);
    setCondition(sel.condition);
    setMediaList(sel.media);
    onAnnounce(`Modelo de ${type} carregado.`);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim()) {
      setErrorMsg('Por favor, informe o título do anúncio.');
      return;
    }

    const numPrice = parseFloat(price.replace(',', '.'));
    if (isNaN(numPrice) || numPrice <= 0) {
      setErrorMsg('Informe um valor de preço válido maior que zero.');
      return;
    }

    if (mediaList.length === 0) {
      setErrorMsg('Adicione pelo menos uma foto ou vídeo do produto.');
      return;
    }

    setErrorMsg('');

    const socialLinks: SocialLinks = {
      phone: phone.trim() || '924258402',
      whatsapp: whatsapp.trim() || undefined,
      instagram: instagram.trim() || undefined,
      facebook: facebook.trim() || undefined,
      tiktok: tiktok.trim() || undefined,
    };

    onCreateProduct({
      seller_id: currentUser.id,
      seller: {
        ...currentUser,
        phone: phone.trim() || currentUser.phone,
        social_links: socialLinks,
      },
      title: title.trim(),
      description: description.trim() || 'Sem descrição adicional fornecida.',
      price: numPrice,
      currency: 'AOA',
      category,
      condition,
      status: 'ACTIVE',
      location: location.trim() || 'Luanda, Angola',
      featured: false,
      socialLinks,
      media: mediaList,
      images: mediaList.map((m, index) => ({
        id: `img-${Date.now()}-${index}`,
        product_id: '',
        image_url: m.url,
        image_order: index,
        alt_text: `Mídia de ${title.trim()}`,
      })),
      tags: [category, condition],
    });

    playChime('success');
    onAnnounce(`Anúncio "${title}" cadastrado com sucesso no Baú da Genevendas!`);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="create-listing-title"
      id="create-listing-modal"
    >
      <div
        className={`relative w-full max-w-2xl rounded-[32px] overflow-hidden shadow-2xl transition-all my-auto ${
          isHighContrast
            ? 'bg-black text-white border-4 border-yellow-400'
            : 'bg-[#FDFCFB] dark:bg-[#1E1C18] text-[#1A1A1A] dark:text-[#FDFCFB] border border-[#E5E1DA] dark:border-[#38342D]'
        }`}
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#E5E1DA] dark:border-[#38342D] bg-[#F5F2ED] dark:bg-[#181613] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-600 dark:text-amber-400" aria-hidden="true" />
            <h2 id="create-listing-title" className="font-serif text-xl md:text-2xl text-[#1A1A1A] dark:text-[#FDFCFB]">
              Publicar Produto para Venda
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar formulário de anúncio"
            className="w-9 h-9 rounded-full hover:bg-[#EAE5DD] dark:hover:bg-[#2A2722] flex items-center justify-center transition-colors text-[#8C8273] dark:text-[#D4CEC3] cursor-pointer"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        {/* Template shortcuts */}
        <div className="px-6 py-3 bg-[#F5F2ED]/70 dark:bg-[#181613]/70 border-b border-[#E5E1DA] dark:border-[#38342D]">
          <span className="text-xs font-bold uppercase tracking-wider text-[#8C8273] dark:text-[#A39B8B] block mb-2">
            Preenchimento Rápido com Exemplos:
          </span>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => applyTemplate('smartphone')}
              className="px-3 py-1 rounded-full text-xs font-medium bg-white dark:bg-[#25231E] text-[#5A5A40] dark:text-[#D4CEC3] border border-[#E5E1DA] dark:border-[#38342D] hover:bg-[#EAE5DD]"
            >
              📱 Celular / Smartphone
            </button>
            <button
              type="button"
              onClick={() => applyTemplate('sofa')}
              className="px-3 py-1 rounded-full text-xs font-medium bg-white dark:bg-[#25231E] text-[#5A5A40] dark:text-[#D4CEC3] border border-[#E5E1DA] dark:border-[#38342D] hover:bg-[#EAE5DD]"
            >
              🛋️ Móveis / Mesa
            </button>
            <button
              type="button"
              onClick={() => applyTemplate('brinquedo')}
              className="px-3 py-1 rounded-full text-xs font-medium bg-white dark:bg-[#25231E] text-[#5A5A40] dark:text-[#D4CEC3] border border-[#E5E1DA] dark:border-[#38342D] hover:bg-[#EAE5DD]"
            >
              🚲 Infantil & Bebê
            </button>
            <button
              type="button"
              onClick={() => applyTemplate('cozinha')}
              className="px-3 py-1 rounded-full text-xs font-medium bg-white dark:bg-[#25231E] text-[#5A5A40] dark:text-[#D4CEC3] border border-[#E5E1DA] dark:border-[#38342D] hover:bg-[#EAE5DD]"
            >
              🍳 Casa & Eletro
            </button>
          </div>
        </div>

        {/* Error notification */}
        {errorMsg && (
          <div className="mx-6 mt-4 p-3 rounded-2xl bg-red-50 dark:bg-red-950/80 border border-red-200 text-red-900 dark:text-red-200 text-xs flex items-center gap-2" role="alert">
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[65vh] overflow-y-auto">
          {/* Upload da Galeria (Fotos ou Vídeos) */}
          <div className="space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-[#8C8273] dark:text-[#A39B8B]">
              Carregar Fotos ou Vídeos da Galeria
            </label>
            
            <label className="border-2 border-dashed border-[#D8D3C8] dark:border-[#403B32] hover:border-amber-500 dark:hover:border-amber-400 rounded-2xl p-5 flex flex-col items-center justify-center cursor-pointer bg-[#F8F6F2] dark:bg-[#25231E] transition-all group">
              <Upload className="w-8 h-8 text-stone-400 group-hover:text-amber-600 dark:group-hover:text-amber-400 mb-1.5 transition-colors" />
              <span className="text-sm font-bold text-stone-700 dark:text-stone-200 group-hover:text-amber-600">
                Abrir Galeria do Dispositivo
              </span>
              <span className="text-xs text-stone-400 dark:text-stone-500 mt-0.5">
                Selecione múltiplas fotos ou vídeos (MP4, WebM, JPEG, PNG)
              </span>
              <input
                type="file"
                multiple
                accept="image/*,video/*"
                onChange={handleMediaFilesChange}
                className="hidden"
              />
            </label>

            {/* Pré-visualização da Galeria de Fotos e Vídeos */}
            {mediaList.length > 0 && (
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5 pt-2">
                {mediaList.map((item) => (
                  <div key={item.id} className="relative h-24 rounded-xl border border-[#E5E1DA] dark:border-[#38342D] overflow-hidden bg-black group">
                    {item.type === 'video' ? (
                      <div className="relative w-full h-full">
                        <video src={item.url} className="w-full h-full object-cover" controls={false} />
                        <div className="absolute top-1 left-1 bg-black/70 text-white p-1 rounded-md">
                          <VideoIcon className="w-3 h-3" />
                        </div>
                      </div>
                    ) : (
                      <div className="relative w-full h-full">
                        <img src={item.url} alt="Mídia" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        <div className="absolute top-1 left-1 bg-black/70 text-white p-1 rounded-md">
                          <ImageIcon className="w-3 h-3" />
                        </div>
                      </div>
                    )}
                    <button
                      type="button"
                      onClick={() => handleRemoveMedia(item.id)}
                      aria-label="Remover mídia"
                      className="absolute inset-0 bg-black/60 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 className="w-5 h-5 text-red-400" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Inserir URL direta (Opcional) */}
            <div className="flex gap-2 pt-1">
              <input
                type="url"
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                placeholder="Ou cole o link de uma foto/vídeo online..."
                className="flex-1 px-4 py-2.5 rounded-xl bg-[#F5F2ED] dark:bg-[#25231E] border border-[#E5E1DA] dark:border-[#38342D] text-xs text-[#1A1A1A] dark:text-[#FDFCFB]"
              />
              <select
                value={urlType}
                onChange={(e) => setUrlType(e.target.value as 'image' | 'video')}
                className="px-3 py-2.5 rounded-xl bg-[#F5F2ED] dark:bg-[#25231E] border border-[#E5E1DA] dark:border-[#38342D] text-xs font-semibold"
              >
                <option value="image">Foto</option>
                <option value="video">Vídeo</option>
              </select>
              <button
                type="button"
                onClick={handleAddMediaUrl}
                className="px-4 py-2.5 rounded-xl bg-[#5A5A40] text-white text-xs font-bold shrink-0"
              >
                Adicionar
              </button>
            </div>
          </div>

          {/* Title */}
          <div>
            <label htmlFor="product-title-input" className="block text-xs font-bold uppercase tracking-wider text-[#8C8273] dark:text-[#A39B8B] mb-1">
              Título do Produto <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="product-title-input"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ex: Smartphone Xiaomi Redmi Note 13 256GB"
              className="w-full px-4 py-3 rounded-2xl bg-[#F5F2ED] dark:bg-[#25231E] border border-[#E5E1DA] dark:border-[#38342D] text-[#1A1A1A] dark:text-[#FDFCFB] text-sm focus:ring-2 focus:ring-amber-500"
            />
          </div>

          {/* Price & Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="product-price-input" className="block text-xs font-bold uppercase tracking-wider text-[#8C8273] dark:text-[#A39B8B] mb-1">
                Preço em Kwanzas (Kz / AOA) <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                step="1"
                min="0"
                id="product-price-input"
                required
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="185000"
                className="w-full px-4 py-3 rounded-2xl bg-[#F5F2ED] dark:bg-[#25231E] border border-[#E5E1DA] dark:border-[#38342D] text-[#1A1A1A] dark:text-[#FDFCFB] text-sm focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div>
              <label htmlFor="product-category-select" className="block text-xs font-bold uppercase tracking-wider text-[#8C8273] dark:text-[#A39B8B] mb-1">
                Categoria
              </label>
              <select
                id="product-category-select"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-4 py-3 rounded-2xl bg-[#F5F2ED] dark:bg-[#25231E] border border-[#E5E1DA] dark:border-[#38342D] text-[#1A1A1A] dark:text-[#FDFCFB] text-sm focus:ring-2 focus:ring-amber-500"
              >
                <option value="eletronicos">Eletrônicos & Celulares</option>
                <option value="casa">Casa & Conforto</option>
                <option value="infantil">Infantil & Bebês</option>
                <option value="livros">Livros & Educação</option>
                <option value="moda">Moda & Calçados</option>
                <option value="ferramentas">Ferramentas & Jardim</option>
              </select>
            </div>
          </div>

          {/* Condition & Location */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#8C8273] dark:text-[#A39B8B] mb-1">
                Condição do Item
              </label>
              <div className="flex gap-2">
                {(['Novo', 'Seminovo', 'Usado'] as ProductCondition[]).map((cond) => (
                  <button
                    key={cond}
                    type="button"
                    onClick={() => setCondition(cond)}
                    className={`flex-1 py-2.5 rounded-2xl text-xs font-bold border transition-all ${
                      condition === cond
                        ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                        : 'bg-white dark:bg-[#25231E] text-[#5A5A40] dark:text-[#D4CEC3] border-[#E5E1DA] dark:border-[#38342D]'
                    }`}
                  >
                    {cond}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label htmlFor="product-location-input" className="block text-xs font-bold uppercase tracking-wider text-[#8C8273] dark:text-[#A39B8B] mb-1">
                Localização / Cidade
              </label>
              <input
                type="text"
                id="product-location-input"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Luanda, Angola"
                className="w-full px-4 py-3 rounded-2xl bg-[#F5F2ED] dark:bg-[#25231E] border border-[#E5E1DA] dark:border-[#38342D] text-[#1A1A1A] dark:text-[#FDFCFB] text-sm focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label htmlFor="product-desc-input" className="block text-xs font-bold uppercase tracking-wider text-[#8C8273] dark:text-[#A39B8B] mb-1">
              Descrição Detalhada
            </label>
            <textarea
              id="product-desc-input"
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Descreva o estado de conservação, acessórios inclusos e forma de entrega..."
              className="w-full px-4 py-3 rounded-2xl bg-[#F5F2ED] dark:bg-[#25231E] border border-[#E5E1DA] dark:border-[#38342D] text-[#1A1A1A] dark:text-[#FDFCFB] text-sm focus:ring-2 focus:ring-amber-500"
            />
          </div>

          {/* Contactos do Vendedor e Redes Sociais */}
          <div className="space-y-3 pt-3 border-t border-[#E5E1DA] dark:border-[#38342D]">
            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#8C8273] dark:text-[#A39B8B]">
                Contactos e Redes Sociais do Vendedor
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-stone-600 dark:text-stone-300 font-semibold mb-1 flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-stone-500" />
                  Telefone Principal <span className="text-red-500">*</span>
                </label>
                <input
                  type="tel"
                  placeholder="924 258 402"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F5F2ED] dark:bg-[#25231E] border border-[#E5E1DA] dark:border-[#38342D] text-xs font-medium text-[#141414] dark:text-[#FDFCFB]"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-stone-600 dark:text-stone-300 font-semibold mb-1 flex items-center gap-1">
                  <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                  WhatsApp
                </label>
                <input
                  type="tel"
                  placeholder="924 258 402"
                  value={whatsapp}
                  onChange={(e) => setWhatsapp(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F5F2ED] dark:bg-[#25231E] border border-[#E5E1DA] dark:border-[#38342D] text-xs font-medium text-[#141414] dark:text-[#FDFCFB]"
                />
              </div>

              <div>
                <label className="block text-xs text-stone-600 dark:text-stone-300 font-semibold mb-1 flex items-center gap-1">
                  <Instagram className="w-3.5 h-3.5 text-pink-600" />
                  Instagram
                </label>
                <input
                  type="text"
                  placeholder="Link ou @utilizador"
                  value={instagram}
                  onChange={(e) => setInstagram(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F5F2ED] dark:bg-[#25231E] border border-[#E5E1DA] dark:border-[#38342D] text-xs font-medium text-[#141414] dark:text-[#FDFCFB]"
                />
              </div>

              <div>
                <label className="block text-xs text-stone-600 dark:text-stone-300 font-semibold mb-1 flex items-center gap-1">
                  <Facebook className="w-3.5 h-3.5 text-blue-600" />
                  Facebook
                </label>
                <input
                  type="text"
                  placeholder="Link do perfil do Facebook"
                  value={facebook}
                  onChange={(e) => setFacebook(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F5F2ED] dark:bg-[#25231E] border border-[#E5E1DA] dark:border-[#38342D] text-xs font-medium text-[#141414] dark:text-[#FDFCFB]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs text-stone-600 dark:text-stone-300 font-semibold mb-1 flex items-center gap-1">
                  <Share2 className="w-3.5 h-3.5 text-purple-600" />
                  Perfil do TikTok
                </label>
                <input
                  type="text"
                  placeholder="Link ou @utilizador do TikTok"
                  value={tiktok}
                  onChange={(e) => setTiktok(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F5F2ED] dark:bg-[#25231E] border border-[#E5E1DA] dark:border-[#38342D] text-xs font-medium text-[#141414] dark:text-[#FDFCFB]"
                />
              </div>
            </div>
          </div>

          {/* Submit buttons */}
          <div className="pt-4 border-t border-[#E5E1DA] dark:border-[#38342D] flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-full font-semibold text-xs text-[#8C8273] dark:text-[#D4CEC3] hover:bg-[#EAE5DD] dark:hover:bg-[#25231E] cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              id="submit-product-btn"
              className={`h-12 px-6 rounded-2xl font-bold text-sm text-white shadow-xs flex items-center gap-2 cursor-pointer ${
                isHighContrast
                  ? 'bg-yellow-400 text-black hover:bg-yellow-300 font-black'
                  : 'bg-amber-600 hover:bg-amber-700 active:scale-98'
              }`}
            >
              <Check className="w-4 h-4" />
              <span>Publicar Produto</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
