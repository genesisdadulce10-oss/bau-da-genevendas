import React, { useState } from 'react';
import { Phone, Copy, Check, ExternalLink, X, MessageSquare } from 'lucide-react';
import { playChime } from '../utils/audio';

interface WhatsAppDialogProps {
  isOpen: boolean;
  onClose: () => void;
  productTitle: string;
  sellerPhone: string;
  theme: string;
  onAnnounce: (msg: string) => void;
}

export const WhatsAppDialog: React.FC<WhatsAppDialogProps> = ({
  isOpen,
  onClose,
  productTitle,
  sellerPhone,
  theme,
  onAnnounce,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const isHighContrast = theme === 'high-contrast';
  const cleanPhone = sellerPhone.replace(/\D/g, '') || '5511999999999';
  const messageText = `Olá! Vi seu anúncio '${productTitle}' no app Baú da Genevendas e tenho interesse.`;
  const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(messageText)}`;

  const handleLaunch = () => {
    playChime('click');
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    onAnnounce('Redirecionando para o WhatsApp do vendedor');
  };

  const handleCopyMessage = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(messageText);
      setCopied(true);
      playChime('success');
      onAnnounce('Texto da mensagem copiado para a área de transferência');
      setTimeout(() => setCopied(false), 2500);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="whatsapp-dialog-title"
      id="whatsapp-integration-dialog"
    >
      <div
        className={`relative w-full max-w-md rounded-[32px] overflow-hidden shadow-2xl p-6 transition-all ${
          isHighContrast
            ? 'bg-black text-white border-4 border-yellow-400'
            : 'bg-[#FDFCFB] dark:bg-[#1E1C18] text-[#1A1A1A] dark:text-[#FDFCFB] border border-[#E5E1DA] dark:border-[#38342D]'
        }`}
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Fechar diálogo do WhatsApp"
          className="absolute top-4 right-4 w-9 h-9 rounded-full hover:bg-[#EAE5DD] dark:hover:bg-[#2A2722] flex items-center justify-center text-[#8C8273] dark:text-[#D4CEC3]"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3.5 mb-5">
          <div className="w-12 h-12 rounded-2xl bg-[#25D366] text-white flex items-center justify-center shadow-xs">
            <Phone className="w-6 h-6 fill-white" />
          </div>
          <div>
            <h3 id="whatsapp-dialog-title" className="font-serif text-lg text-[#1A1A1A] dark:text-[#FDFCFB]">
              Contato via WhatsApp
            </h3>
            <p className="text-xs text-[#8C8273] dark:text-[#A39B8B]">
              Número: +{cleanPhone}
            </p>
          </div>
        </div>

        <div className="space-y-3 mb-6">
          <div className="p-4 rounded-2xl bg-[#F5F2ED] dark:bg-[#25231E] border border-[#E5E1DA] dark:border-[#38342D] text-xs">
            <span className="font-bold text-[#8C8273] uppercase tracking-wider block mb-1 text-[10px]">
              Mensagem Pré-configurada:
            </span>
            <p className="font-medium text-[#4A443A] dark:text-[#D4CEC3] italic leading-relaxed">
              "{messageText}"
            </p>
          </div>
        </div>

        <div className="flex flex-col gap-3">
          <button
            type="button"
            onClick={handleLaunch}
            className={`w-full h-12 px-4 rounded-2xl font-bold text-sm text-white flex items-center justify-center gap-2 shadow-xs transition-all ${
              isHighContrast
                ? 'bg-emerald-400 text-black hover:bg-emerald-300 font-black'
                : 'bg-[#25D366] hover:opacity-90 active:scale-98'
            }`}
          >
            <ExternalLink className="w-4 h-4" />
            <span>Abrir WhatsApp Web / App</span>
          </button>

          <button
            type="button"
            onClick={handleCopyMessage}
            className="w-full h-11 px-4 rounded-2xl font-semibold text-xs border border-[#E5E1DA] dark:border-[#38342D] bg-white dark:bg-[#25231E] text-[#5A5A40] dark:text-[#D4CEC3] hover:bg-[#EAE5DD] flex items-center justify-center gap-1.5 transition-all"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-[#2D5A27] dark:text-[#74BF6B]" />
                <span className="text-[#2D5A27] dark:text-[#74BF6B] font-bold">Mensagem Copiada!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-[#8C8273]" />
                <span>Copiar Texto da Mensagem</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
