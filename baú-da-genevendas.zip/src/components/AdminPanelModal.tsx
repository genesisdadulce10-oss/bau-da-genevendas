import React, { useState, useEffect } from 'react';
import { 
  X, 
  Trash2, 
  PauseCircle, 
  CheckCircle2, 
  Shield, 
  Search, 
  Eye, 
  ExternalLink,
  MapPin,
  Tag,
  AlertTriangle,
  Bell,
  BellRing,
  Smartphone
} from 'lucide-react';
import { Product, ProductStatus } from '../types';
import { formatPriceBRL } from '../utils/speech';
import { registerMainDevice } from '../services/firebaseClient';

interface AdminPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onDeleteProduct: (id: string) => void;
  onUpdateStatus?: (id: string, status: ProductStatus) => void;
  onSelectProduct?: (product: Product) => void;
  theme?: string;
  onAnnounce?: (msg: string) => void;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  isOpen,
  onClose,
  products,
  onDeleteProduct,
  onUpdateStatus,
  onSelectProduct,
  theme = 'light',
  onAnnounce,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [deviceStatus, setDeviceStatus] = useState<{ isRegistered: boolean; loading: boolean; message: string }>({
    isRegistered: false,
    loading: false,
    message: '',
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('admin_device_token');
      if (token) {
        setDeviceStatus({
          isRegistered: true,
          loading: false,
          message: 'Dispositivo Principal Registrado para Alertas FCM',
        });
      }
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const isHighContrast = theme === 'high-contrast';

  const handleRegisterDevice = async () => {
    setDeviceStatus((prev) => ({ ...prev, loading: true }));
    await registerMainDevice((res) => {
      setDeviceStatus({
        isRegistered: res.success,
        loading: false,
        message: res.message,
      });
      if (res.success) {
        onAnnounce?.('Dispositivo registrado com sucesso para receber notificações de novos anúncios e mensagens.');
      }
    });
  };

  const filtered = products.filter((p) => {
    if (filterStatus !== 'all' && p.status !== filterStatus) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const inTitle = p.title.toLowerCase().includes(q);
      const inSeller = p.seller?.name?.toLowerCase().includes(q) || p.seller_id.toLowerCase().includes(q);
      const inLocation = p.location?.toLowerCase().includes(q);
      if (!inTitle && !inSeller && !inLocation) return false;
    }
    return true;
  });

  const handleDelete = (id: string, title: string) => {
    onDeleteProduct(id);
    setConfirmDeleteId(null);
    onAnnounce?.(`Anúncio "${title}" excluído com sucesso pelo Administrador.`);
  };

  const handleToggleStatus = (product: Product) => {
    if (!onUpdateStatus) return;
    const nextStatus: ProductStatus = product.status === 'ACTIVE' ? 'PAUSED' : 'ACTIVE';
    onUpdateStatus(product.id, nextStatus);
    onAnnounce?.(`Status do anúncio "${product.title}" alterado para ${nextStatus === 'ACTIVE' ? 'Disponível' : 'Pausado'}.`);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 md:p-6 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="admin-panel-title"
      id="admin-panel-modal"
    >
      <div
        className={`relative w-full max-w-4xl max-h-[90vh] rounded-[28px] overflow-hidden shadow-2xl flex flex-col transition-all ${
          isHighContrast
            ? 'bg-black text-white border-4 border-yellow-400'
            : 'bg-[#FDFCFB] dark:bg-[#1C1A17] text-[#1A1A1A] dark:text-[#FDFCFB] border border-[#E5E1DA] dark:border-[#38342D]'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#E5E1DA] dark:border-[#38342D] bg-[#F5F2ED]/80 dark:bg-[#181613]/80">
          <div className="flex items-center space-x-3 text-red-600 dark:text-red-400">
            <div className="p-2 rounded-xl bg-red-100 dark:bg-red-950/80 border border-red-200 dark:border-red-800">
              <Shield className="w-6 h-6 text-red-600 dark:text-red-400" aria-hidden="true" />
            </div>
            <div>
              <h2 id="admin-panel-title" className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2 font-serif">
                <span>Painel de Acesso Total (Admin)</span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-red-600 text-white font-bold">
                  Superuser
                </span>
              </h2>
              <p className="text-xs text-[#8C8273] dark:text-[#A39B8B]">
                Gerenciamento global de conteúdo, moderação e controle de anúncios
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="Fechar Painel do Administrador"
            className="p-2 hover:bg-[#EAE5DD] dark:hover:bg-[#2A2722] rounded-full transition-colors text-[#8C8273] dark:text-[#D4CEC3]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Device FCM Push Notifications Registration Card */}
        <div className="px-6 py-3.5 bg-amber-50/80 dark:bg-[#252015] border-b border-amber-200 dark:border-amber-900/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-lg bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <p className="font-bold text-amber-950 dark:text-amber-100">
                Notificações Push do Dispositivo Principal (FCM)
              </p>
              <p className="text-amber-800/80 dark:text-amber-300/70">
                {deviceStatus.isRegistered
                  ? 'Dispositivo conectado! Você receberá alertas em tempo real de novos anúncios e chats.'
                  : 'Ative para receber alertas instantâneos de novos produtos e mensagens enviadas.'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleRegisterDevice}
            disabled={deviceStatus.loading}
            className={`px-3.5 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1.5 shrink-0 ${
              deviceStatus.isRegistered
                ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                : 'bg-amber-600 hover:bg-amber-700 text-white shadow-xs'
            }`}
          >
            {deviceStatus.loading ? (
              <span>Registrando...</span>
            ) : deviceStatus.isRegistered ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Dispositivo Ativo</span>
              </>
            ) : (
              <>
                <BellRing className="w-3.5 h-3.5" />
                <span>Registrar Meu Dispositivo</span>
              </>
            )}
          </button>
        </div>

        {/* Search and Filters Bar */}
        <div className="p-5 border-b border-[#E5E1DA] dark:border-[#38342D] bg-[#FDFCFB] dark:bg-[#1C1A17] flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="relative w-full sm:max-w-md">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#8C8273]" aria-hidden="true" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar por título, vendedor ou local..."
              className="w-full pl-10 pr-4 py-2 text-sm rounded-xl bg-[#F5F2ED] dark:bg-[#26231E] border border-[#E5E1DA] dark:border-[#38342D] text-[#1A1A1A] dark:text-[#FDFCFB] placeholder-[#8C8273] focus:outline-none focus:ring-2 focus:ring-red-500"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
            <div className="flex rounded-xl overflow-hidden border border-[#E5E1DA] dark:border-[#38342D] text-xs font-semibold">
              <button
                type="button"
                onClick={() => setFilterStatus('all')}
                className={`px-3 py-1.5 transition-colors ${
                  filterStatus === 'all'
                    ? 'bg-[#5A5A40] text-white'
                    : 'bg-[#F5F2ED] dark:bg-[#26231E] text-[#5A5A40] dark:text-[#D4CEC3]'
                }`}
              >
                Todos ({products.length})
              </button>
              <button
                type="button"
                onClick={() => setFilterStatus('ACTIVE')}
                className={`px-3 py-1.5 transition-colors ${
                  filterStatus === 'ACTIVE'
                    ? 'bg-[#5A5A40] text-white'
                    : 'bg-[#F5F2ED] dark:bg-[#26231E] text-[#5A5A40] dark:text-[#D4CEC3]'
                }`}
              >
                Ativos ({products.filter((p) => p.status === 'ACTIVE').length})
              </button>
              <button
                type="button"
                onClick={() => setFilterStatus('PAUSED')}
                className={`px-3 py-1.5 transition-colors ${
                  filterStatus === 'PAUSED'
                    ? 'bg-[#5A5A40] text-white'
                    : 'bg-[#F5F2ED] dark:bg-[#26231E] text-[#5A5A40] dark:text-[#D4CEC3]'
                }`}
              >
                Pausados ({products.filter((p) => p.status === 'PAUSED').length})
              </button>
            </div>
          </div>
        </div>

        {/* Listings Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-[#8C8273] dark:text-[#A39B8B] space-y-2">
              <p className="text-base font-semibold">Nenhum anúncio encontrado para este filtro.</p>
              <p className="text-xs">Tente buscar por outro termo ou redefinir os filtros.</p>
            </div>
          ) : (
            <div className="divide-y divide-[#E5E1DA] dark:divide-[#38342D] border border-[#E5E1DA] dark:border-[#38342D] rounded-2xl overflow-hidden">
              {filtered.map((product) => {
                const isConfirming = confirmDeleteId === product.id;

                return (
                  <div
                    key={product.id}
                    className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white dark:bg-[#23211D] hover:bg-[#FDFCFB] dark:hover:bg-[#2A2722] transition-colors"
                  >
                    {/* Product Preview */}
                    <div className="flex items-center space-x-3.5 flex-1 min-w-0">
                      <img
                        src={product.images[0]?.image_url || 'https://images.unsplash.com/photo-1580910051074-3eb694886505?w=200&auto=format&fit=crop&q=80'}
                        alt={product.title}
                        className="w-14 h-14 rounded-xl object-cover border border-[#E5E1DA] dark:border-[#38342D] shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="font-semibold text-sm text-gray-900 dark:text-white truncate">
                            {product.title}
                          </p>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                              product.status === 'ACTIVE'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border-emerald-300'
                                : product.status === 'PAUSED'
                                ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300 border-amber-300'
                                : 'bg-slate-200 text-slate-800 dark:bg-slate-800 dark:text-slate-300 border-slate-400'
                            }`}
                          >
                            {product.status === 'ACTIVE' ? 'Disponível' : product.status === 'PAUSED' ? 'Pausado' : 'Vendido'}
                          </span>
                        </div>
                        <p className="text-xs text-[#8C8273] dark:text-[#A39B8B] mt-0.5 truncate">
                          Vendedor: <span className="font-medium text-[#1A1A1A] dark:text-[#EAE5DD]">{product.seller?.name || product.seller_id}</span> • {product.location} • <span className="font-bold text-[#2D5A27] dark:text-[#74BF6B]">{formatPriceBRL(product.price)}</span>
                        </p>
                      </div>
                    </div>

                    {/* Admin Action Buttons */}
                    <div className="flex items-center space-x-2 w-full sm:w-auto justify-end">
                      {/* View Details */}
                      {onSelectProduct && (
                        <button
                          type="button"
                          onClick={() => {
                            onSelectProduct(product);
                            onClose();
                          }}
                          className="p-2 rounded-xl text-[#5A5A40] hover:bg-[#F5F2ED] dark:text-[#D4CEC3] dark:hover:bg-[#2A2722] transition-colors"
                          title="Ver anúncio completo"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      )}

                      {/* Toggle Status */}
                      {onUpdateStatus && (
                        <button
                          type="button"
                          onClick={() => handleToggleStatus(product)}
                          className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-[#F5F2ED] hover:bg-[#EAE5DD] text-[#5A5A40] dark:bg-[#2A2722] dark:hover:bg-[#343029] dark:text-[#D4CEC3] border border-[#E5E1DA] dark:border-[#38342D] transition-colors flex items-center gap-1"
                          title={product.status === 'ACTIVE' ? 'Pausar anúncio' : 'Ativar anúncio'}
                        >
                          {product.status === 'ACTIVE' ? (
                            <>
                              <PauseCircle className="w-3.5 h-3.5 text-amber-600" />
                              <span>Pausar</span>
                            </>
                          ) : (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              <span>Ativar</span>
                            </>
                          )}
                        </button>
                      )}

                      {/* Delete / Confirm Delete */}
                      {isConfirming ? (
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleDelete(product.id, product.title)}
                            className="bg-red-600 hover:bg-red-700 text-white px-2.5 py-1.5 rounded-xl text-xs font-bold transition-colors"
                          >
                            Confirmar Exclusão
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(null)}
                            className="bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-200 px-2 py-1.5 rounded-xl text-xs"
                          >
                            Cancelar
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(product.id)}
                          className="flex items-center space-x-1 bg-red-100 dark:bg-red-950/60 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-900 px-3 py-1.5 rounded-xl text-xs font-semibold hover:bg-red-200 dark:hover:bg-red-900/80 transition-colors"
                          title="Remover este anúncio da plataforma"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Excluir</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-[#E5E1DA] dark:border-[#38342D] bg-[#F5F2ED]/70 dark:bg-[#181613]/70 flex items-center justify-between">
          <span className="text-xs text-[#8C8273] dark:text-[#A39B8B]">
            Total de anúncios moderáveis: <strong>{products.length}</strong>
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-[#5A5A40] text-white hover:bg-[#484833] transition-colors"
          >
            Fechar Painel
          </button>
        </div>
      </div>
    </div>
  );
};
