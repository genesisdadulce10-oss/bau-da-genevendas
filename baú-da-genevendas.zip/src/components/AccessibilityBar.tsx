import React from 'react';
import { AccessibilitySettings } from '../types';
import { 
  Sun, 
  Moon, 
  Eye, 
  Type, 
  Volume2, 
  VolumeX, 
  Sparkles,
  Sliders
} from 'lucide-react';

interface AccessibilityBarProps {
  settings: AccessibilitySettings;
  onUpdateSettings: (newSettings: Partial<AccessibilitySettings>) => void;
  isOpen: boolean;
  onToggleOpen: () => void;
  onAnnounce: (msg: string) => void;
}

export const AccessibilityBar: React.FC<AccessibilityBarProps> = ({
  settings,
  onUpdateSettings,
  isOpen,
  onToggleOpen,
  onAnnounce,
}) => {
  const toggleHighContrast = () => {
    const nextTheme = settings.theme === 'high-contrast' ? 'light' : 'high-contrast';
    onUpdateSettings({ theme: nextTheme });
    onAnnounce(nextTheme === 'high-contrast' ? 'Modo Alto Contraste ativado' : 'Modo padrão ativado');
  };

  const toggleDarkMode = () => {
    const nextTheme = settings.theme === 'dark' ? 'light' : 'dark';
    onUpdateSettings({ theme: nextTheme });
    onAnnounce(nextTheme === 'dark' ? 'Modo escuro ativado' : 'Modo claro ativado');
  };

  const handleFontScale = (scale: AccessibilitySettings['textScale']) => {
    onUpdateSettings({ textScale: scale });
    const labels = { normal: 'normal', large: 'grande', xlarge: 'extra grande' };
    onAnnounce(`Tamanho do texto alterado para ${labels[scale]}`);
  };

  return (
    <div className="w-full bg-[#F5F2ED] dark:bg-[#181613] text-[#4A443A] dark:text-[#D4CEC3] border-b border-[#E5E1DA] dark:border-[#2E2C27] text-xs transition-all duration-200">
      <div className="max-w-6xl mx-auto px-4 py-2 flex flex-wrap items-center justify-between gap-3">
        {/* Skip to content link */}
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:top-2 focus:left-2 focus:px-4 focus:py-2 focus:bg-[#5A5A40] focus:text-white focus:font-bold focus:rounded-full focus:shadow-lg"
          id="skip-to-content"
        >
          Pular para o conteúdo principal (Alt + 1)
        </a>

        {/* Quick Accessibility Shortcuts */}
        <div className="flex items-center flex-wrap gap-2">
          <span className="font-semibold text-[#5A5A40] dark:text-[#A3A08A] flex items-center gap-1.5 mr-1" aria-hidden="true">
            <Eye className="w-3.5 h-3.5 text-[#5A5A40] dark:text-[#A3A08A]" />
            <span>Acessibilidade:</span>
          </span>

          {/* High Contrast Toggle Button */}
          <button
            id="toggle-high-contrast-btn"
            type="button"
            onClick={toggleHighContrast}
            aria-pressed={settings.theme === 'high-contrast'}
            aria-label="Alternar modo de alto contraste"
            className={`px-3 py-1 rounded-full font-medium transition-colors flex items-center gap-1.5 border ${
              settings.theme === 'high-contrast'
                ? 'bg-yellow-400 text-black border-yellow-300 font-bold'
                : 'bg-white dark:bg-[#25231E] hover:bg-[#EAE5DD] text-[#4A443A] dark:text-[#D4CEC3] border-[#E5E1DA] dark:border-[#38342D]'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-[#5A5A40] dark:text-[#A3A08A]" aria-hidden="true" />
            <span>Alto Contraste</span>
          </button>

          {/* Dark / Light Theme Toggle */}
          <button
            id="toggle-theme-mode-btn"
            type="button"
            onClick={toggleDarkMode}
            aria-label={settings.theme === 'dark' ? 'Mudar para tema claro' : 'Mudar para tema escuro'}
            className="px-3 py-1 rounded-full bg-white dark:bg-[#25231E] hover:bg-[#EAE5DD] text-[#4A443A] dark:text-[#D4CEC3] border border-[#E5E1DA] dark:border-[#38342D] font-medium transition-colors flex items-center gap-1.5"
          >
            {settings.theme === 'dark' ? (
              <>
                <Sun className="w-3.5 h-3.5 text-amber-500" aria-hidden="true" />
                <span>Tema Claro</span>
              </>
            ) : (
              <>
                <Moon className="w-3.5 h-3.5 text-[#5A5A40]" aria-hidden="true" />
                <span>Tema Escuro</span>
              </>
            )}
          </button>

          {/* Font Resizing Buttons */}
          <div className="flex items-center bg-white dark:bg-[#25231E] rounded-full border border-[#E5E1DA] dark:border-[#38342D] px-1 py-0.5" role="group" aria-label="Ajuste do tamanho da fonte">
            <button
              id="font-scale-normal-btn"
              type="button"
              onClick={() => handleFontScale('normal')}
              aria-pressed={settings.textScale === 'normal'}
              aria-label="Fonte tamanho normal"
              className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                settings.textScale === 'normal' ? 'bg-[#5A5A40] text-white' : 'text-[#4A443A] dark:text-[#D4CEC3] hover:text-[#1A1A1A]'
              }`}
            >
              A
            </button>
            <button
              id="font-scale-large-btn"
              type="button"
              onClick={() => handleFontScale('large')}
              aria-pressed={settings.textScale === 'large'}
              aria-label="Fonte tamanho grande (+20%)"
              className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                settings.textScale === 'large' ? 'bg-[#5A5A40] text-white' : 'text-[#4A443A] dark:text-[#D4CEC3] hover:text-[#1A1A1A]'
              }`}
            >
              A+
            </button>
            <button
              id="font-scale-xlarge-btn"
              type="button"
              onClick={() => handleFontScale('xlarge')}
              aria-pressed={settings.textScale === 'xlarge'}
              aria-label="Fonte tamanho extra grande (+40%)"
              className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                settings.textScale === 'xlarge' ? 'bg-[#5A5A40] text-white' : 'text-[#4A443A] dark:text-[#D4CEC3] hover:text-[#1A1A1A]'
              }`}
            >
              A++
            </button>
          </div>
        </div>

        {/* Right side controls */}
        <div className="flex items-center gap-2">
          {/* Sound toggle */}
          <button
            id="toggle-sound-btn"
            type="button"
            onClick={() => {
              const next = !settings.soundEnabled;
              onUpdateSettings({ soundEnabled: next });
              onAnnounce(next ? 'Sons do aplicativo ativados' : 'Sons do aplicativo silenciados');
            }}
            aria-pressed={settings.soundEnabled}
            aria-label={settings.soundEnabled ? 'Silenciar avisos sonoros' : 'Ativar avisos sonoros'}
            className="p-1.5 rounded-full bg-white dark:bg-[#25231E] hover:bg-[#EAE5DD] text-[#4A443A] dark:text-[#D4CEC3] border border-[#E5E1DA] dark:border-[#38342D] transition-colors"
            title={settings.soundEnabled ? 'Sons ativados' : 'Sons desativados'}
          >
            {settings.soundEnabled ? (
              <Volume2 className="w-3.5 h-3.5 text-[#5A5A40] dark:text-[#A3A08A]" aria-hidden="true" />
            ) : (
              <VolumeX className="w-3.5 h-3.5 text-[#8C8273]" aria-hidden="true" />
            )}
          </button>

          {/* More Accessibility Options Toggle */}
          <button
            id="toggle-more-access-panel-btn"
            type="button"
            onClick={onToggleOpen}
            aria-expanded={isOpen}
            aria-label="Abrir painel detalhado de acessibilidade e filtros para daltônicos"
            className={`px-3 py-1 rounded-full font-medium transition-colors flex items-center gap-1.5 border ${
              isOpen
                ? 'bg-[#5A5A40] text-white border-[#5A5A40]'
                : 'bg-white dark:bg-[#25231E] hover:bg-[#EAE5DD] text-[#4A443A] dark:text-[#D4CEC3] border-[#E5E1DA] dark:border-[#38342D]'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Opções Acessíveis</span>
          </button>
        </div>
      </div>

      {/* Expanded Accessibility Settings Drawer */}
      {isOpen && (
        <div 
          id="detailed-accessibility-drawer" 
          className="bg-[#EAE5DD] dark:bg-[#151412] border-t border-[#E5E1DA] dark:border-[#2E2C27] px-4 py-4 text-[#4A443A] dark:text-[#D4CEC3]"
          role="region"
          aria-label="Painel detalhado de acessibilidade"
        >
          <div className="max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {/* Colorblindness Filter */}
            <div className="p-4 bg-white dark:bg-[#1E1C18] rounded-2xl border border-[#E5E1DA] dark:border-[#38342D]">
              <label htmlFor="colorblind-filter-select" className="block font-bold text-sm text-[#1A1A1A] dark:text-[#FDFCFB] mb-1">
                Paleta para Daltonismo:
              </label>
              <p className="text-[11px] text-[#8C8273] mb-2">
                Ajuste as cores para diferentes tipos de percepção visual.
              </p>
              <select
                id="colorblind-filter-select"
                value={settings.colorblindMode}
                onChange={(e) => {
                  const mode = e.target.value as AccessibilitySettings['colorblindMode'];
                  onUpdateSettings({ colorblindMode: mode });
                  onAnnounce(`Modo de visão alterado para ${mode}`);
                }}
                className="w-full bg-[#F5F2ED] dark:bg-[#282520] border border-[#E5E1DA] dark:border-[#38342D] rounded-xl px-3 py-2 text-xs text-[#1A1A1A] dark:text-[#FDFCFB] focus:ring-2 focus:ring-[#5A5A40]"
              >
                <option value="none">Visão Padrão (Sem filtro)</option>
                <option value="protanopia">Protanopia / Deuteranopia (Vermelho-Verde)</option>
                <option value="tritanopia">Tritanopia (Azul-Amarelo)</option>
                <option value="monochrome">Monocromático (Escala de cinza)</option>
              </select>
            </div>

            {/* Screen reader & Audio Guide */}
            <div className="p-4 bg-white dark:bg-[#1E1C18] rounded-2xl border border-[#E5E1DA] dark:border-[#38342D]">
              <span className="block font-bold text-sm text-[#1A1A1A] dark:text-[#FDFCFB] mb-1">
                Voz e Audiodescrição:
              </span>
              <p className="text-[11px] text-[#8C8273] mb-2">
                Ouvir leitura automática de preços e detalhes dos anúncios ao clicar.
              </p>
              <label className="flex items-center gap-2 cursor-pointer mt-1">
                <input
                  type="checkbox"
                  id="checkbox-voice-reader"
                  checked={settings.screenReaderVoice}
                  onChange={(e) => {
                    const checked = e.target.checked;
                    onUpdateSettings({ screenReaderVoice: checked });
                    onAnnounce(checked ? 'Leitor de voz ativado' : 'Leitor de voz desativado');
                  }}
                  className="w-4 h-4 rounded text-[#5A5A40] focus:ring-[#5A5A40]"
                />
                <span className="text-xs text-[#4A443A] dark:text-[#D4CEC3]">
                  Habilitar botão de leitura por voz nos produtos
                </span>
              </label>
            </div>

            {/* Keyboard shortcuts helper */}
            <div className="p-4 bg-white dark:bg-[#1E1C18] rounded-2xl border border-[#E5E1DA] dark:border-[#38342D]">
              <span className="block font-bold text-sm text-[#1A1A1A] dark:text-[#FDFCFB] mb-1">
                Atalhos de Teclado:
              </span>
              <ul className="text-[11px] text-[#8C8273] space-y-1">
                <li><kbd className="px-1.5 py-0.5 bg-[#F5F2ED] dark:bg-[#25231E] rounded text-[#1A1A1A] dark:text-[#D4CEC3] font-mono text-[10px] border border-[#E5E1DA] dark:border-[#38342D]">Tab</kbd> : Navegar entre botões e produtos</li>
                <li><kbd className="px-1.5 py-0.5 bg-[#F5F2ED] dark:bg-[#25231E] rounded text-[#1A1A1A] dark:text-[#D4CEC3] font-mono text-[10px] border border-[#E5E1DA] dark:border-[#38342D]">Enter</kbd> ou <kbd className="px-1.5 py-0.5 bg-[#F5F2ED] dark:bg-[#25231E] rounded text-[#1A1A1A] dark:text-[#D4CEC3] font-mono text-[10px] border border-[#E5E1DA] dark:border-[#38342D]">Espaço</kbd> : Abrir anúncio</li>
                <li><kbd className="px-1.5 py-0.5 bg-[#F5F2ED] dark:bg-[#25231E] rounded text-[#1A1A1A] dark:text-[#D4CEC3] font-mono text-[10px] border border-[#E5E1DA] dark:border-[#38342D]">Esc</kbd> : Fechar detalhes ou chat</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
