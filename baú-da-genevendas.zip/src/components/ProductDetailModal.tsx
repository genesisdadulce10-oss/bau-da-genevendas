import React, { useState, useEffect } from 'react';
import { Product, User } from '../types';
import { formatPriceBRL, speakText, stopSpeaking } from '../utils/speech';
import { ExpressPaymentModal } from './ExpressPaymentModal';
import { 
  X, 
  Phone, 
  MessageCircle, 
  Volume2, 
  VolumeX, 
  Share2, 
  ShieldCheck, 
  Star, 
  MapPin, 
  Tag, 
  CheckCircle2, 
  PauseCircle, 
  XCircle, 
  ChevronLeft, 
  ChevronRight, 
  Trash2,
  Sparkles,
  Instagram,
  Facebook,
  ShoppingBag,
  Loader2,
  AlertCircle
} from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onOpenChat: (product: Product) => void;
  onOpenWhatsApp: (product: Product) => void;
  theme: string;
  onAnnounce: (msg: string) => void;
  currentUser?: User;
  onDeleteProduct?: (productId: string) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onOpenChat,
  onOpenWhatsApp,
  theme,
  onAnnounce,
  currentUser,
  onDeleteProduct,
}) => {
  const [selectedMediaIndex, setSelectedMediaIndex] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);
  const [showExpressModal, setShowExpressModal] = useState(false);

  // Direct Order / Checkout Modal State
  const [showOrderCheckout, setShowOrderCheckout] = useState(false);
  const [buyerPhone, setBuyerPhone] = useState(currentUser?.phone || '924258402');
  const [isOrdering, setIsOrdering] = useState(false);
  const [orderResult, setOrderResult] = useState<{
    success: boolean;
    message: string;
    summary?: { totalPaid: number; siteFee: number; sellerReceived: number; reference?: string };
  } | null>(null);

  useEffect(() => {
    setSelectedMediaIndex(0);
    setIsSpeaking(false);
    setShowOrderCheckout(false);
    setOrderResult(null);
    return () => {
      stopSpeaking();
    };
  }, [product]);

  // Keyboard navigation: Escape to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!product) return null;

  const isHighContrast = theme === 'high-contrast';

  // Construct combined media list (from product.media or product.images)
  const mediaItems: Array<{ id: string; url: string; type: 'image' | 'video'; alt: string }> = 
    product.media && product.media.length > 0
      ? product.media.map((m, idx) => ({
          id: m.id || `m-${idx}`,
          url: m.url,
          type: m.type,
          alt: `Mídia ${idx + 1} de ${product.title}`,
        }))
      : product.images && product.images.length > 0
      ? product.images.map((img, idx) => ({
          id: img.id || `img-${idx}`,
          url: img.image_url,
          type: 'image' as const,
          alt: img.alt_text || `Foto de ${product.title}`,
        }))
      : [
          {
            id: 'default-img',
            url: 'https://images.unsplash.com/photo-1580910051074-3eb694886505?w=800&auto=format&fit=crop&q=80',
            type: 'image' as const,
            alt: `Foto ilustrativa de ${product.title}`,
          },
        ];

  const currentMedia = mediaItems[selectedMediaIndex] || mediaItems[0];

  // Social Links
  const socialLinks = product.socialLinks || product.seller?.social_links || {};
  const sellerPhone = socialLinks.phone || product.seller?.phone || '924258402';
  const whatsappNumber = (socialLinks.whatsapp || sellerPhone).replace(/\D/g, '');

  const handleSpeakDetails = () => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      onAnnounce('Leitura por voz pausada');
    } else {
      const speechText = `Anúncio: ${product.title}. Preço: ${product.price.toLocaleString('pt-AO')} Kwanzas. Condição: ${product.condition}. Localização: ${product.location}. Descrição do produto: ${product.description}. Vendedor: ${product.seller?.name || 'Vendedor Verificado'}.`;
      setIsSpeaking(true);
      onAnnounce('Iniciando leitura em voz alta do produto');
      speakText(speechText, () => setIsSpeaking(false));
    }
  };

  const handleCopyShareLink = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopySuccess(true);
      onAnnounce('Link do anúncio copiado para a área de transferência');
      setTimeout(() => setCopySuccess(false), 2500);
    }
  };

  const handleDirectBuy = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!buyerPhone || buyerPhone.trim().length < 9) {
      alert('Por favor informe um número de telefone Multicaixa Express válido.');
      return;
    }

    setIsOrdering(true);
    setOrderResult(null);
    onAnnounce('Processando solicitação de compra via Express...');

    try {
      const res = await fetch('/api/orders/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: product.id,
          productPrice: product.price,
          productTitle: product.title,
          buyerPhone: buyerPhone.trim(),
          sellerPhone: sellerPhone,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setOrderResult({
          success: true,
          message: data.message || 'Compra solicitada com sucesso no Multicaixa Express!',
          summary: data.summary,
        });
        onAnnounce('Solicitação de compra enviada com sucesso para o seu Multicaixa Express!');
      } else {
        setOrderResult({
          success: false,
          message: data.error || 'Falha ao processar o débito Express. Tente novamente.',
        });
        onAnnounce('Erro ao efetuar compra.');
      }
    } catch (err) {
      console.error('Erro na compra:', err);
      setOrderResult({
        success: false,
        message: 'Erro de conexão com o servidor de pagamento.',
      });
    } finally {
      setIsOrdering(false);
    }
  };

  const statusMap = {
    ACTIVE: { label: 'Disponível para Compra', icon: CheckCircle2, color: 'text-emerald-700 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-950/80 border-emerald-300' },
    PAUSED: { label: 'Anúncio Pausado', icon: PauseCircle, color: 'text-amber-700 dark:text-amber-400 bg-amber-100 dark:bg-amber-950/80 border-amber-300' },
    SOLD: { label: 'Produto Já Vendido', icon: XCircle, color: 'text-slate-700 dark:text-slate-400 bg-slate-200 dark:bg-slate-800 border-slate-400' },
  };

  const statusInfo = statusMap[product.status] || statusMap.ACTIVE;
  const StatusIcon = statusInfo.icon;

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 md:p-6"
      role="dialog"
      aria-modal="true"
      aria-labelledby="product-detail-title"
      id="product-detail-modal"
    >
      <div
        className={`relative w-full max-w-3xl rounded-[32px] overflow-hidden shadow-2xl transition-all my-auto ${
          isHighContrast
            ? 'bg-black text-white border-4 border-yellow-400'
            : 'bg-[#FDFCFB] dark:bg-[#1E1C18] text-[#1A1A1A] dark:text-[#FDFCFB] border border-[#E5E1DA] dark:border-[#38342D]'
        }`}
      >
        {/* Header bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#E5E1DA] dark:border-[#38342D] bg-[#F5F2ED]/70 dark:bg-[#181613]/70">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#5A5A40] dark:text-[#A3A08A]">
              Detalhes do Anúncio
            </span>
          </div>
          <button
            id="close-product-detail-btn"
            type="button"
            onClick={onClose}
            aria-label="Fechar detalhes do anúncio"
            className="w-10 h-10 rounded-full hover:bg-[#EAE5DD] dark:hover:bg-[#2A2722] flex items-center justify-center transition-colors text-[#8C8273] dark:text-[#D4CEC3] cursor-pointer"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        {/* Content body */}
        <div className="p-6 md:p-8 max-h-[80vh] overflow-y-auto space-y-6">
          {/* Main Media Viewer (Photo / Video) */}
          <div className="space-y-3">
            <div className="relative aspect-[16/10] sm:aspect-[16/9] w-full rounded-[28px] overflow-hidden bg-black border border-[#E5E1DA] dark:border-[#38342D] flex items-center justify-center">
              {currentMedia.type === 'video' ? (
                <video
                  src={currentMedia.url}
                  controls
                  className="w-full h-full object-contain"
                />
              ) : (
                <img
                  src={currentMedia.url}
                  alt={currentMedia.alt}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              )}

              {/* Status and Condition Tag */}
              <div className="absolute top-4 left-4 flex flex-wrap gap-2 pointer-events-none">
                <span
                  className={`inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-bold border shadow-xs ${statusInfo.color}`}
                >
                  <StatusIcon className="w-4 h-4" aria-hidden="true" />
                  <span>{statusInfo.label}</span>
                </span>
                <span className="px-3.5 py-1 rounded-full text-xs font-bold bg-white/95 dark:bg-[#1E1C18]/95 text-[#4A443A] dark:text-[#D4CEC3] shadow-xs border border-[#E5E1DA] dark:border-[#38342D]">
                  {product.condition}
                </span>
              </div>

              {/* Prev / Next Image buttons if multiple */}
              {mediaItems.length > 1 && (
                <>
                  <button
                    type="button"
                    onClick={() => setSelectedMediaIndex((prev) => (prev - 1 + mediaItems.length) % mediaItems.length)}
                    aria-label="Mídia anterior"
                    className="absolute left-3 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-black/60 hover:bg-black/80 text-white backdrop-blur-xs transition-colors cursor-pointer"
                  >
                    <ChevronLeft className="w-5 h-5" aria-hidden="true" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedMediaIndex((prev) => (prev + 1) % mediaItems.length)}
                    aria-label="Próxima mídia"
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-black/60 hover:bg-black/80 text-white backdrop-blur-xs transition-colors cursor-pointer"
                  >
                    <ChevronRight className="w-5 h-5" aria-hidden="true" />
                  </button>
                </>
              )}
            </div>

            {/* Thumbnail selector */}
            {mediaItems.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label="Galeria de fotos e vídeos">
                {mediaItems.map((item, idx) => (
                  <button
                    key={item.id}
                    type="button"
                    role="tab"
                    aria-selected={selectedMediaIndex === idx}
                    onClick={() => setSelectedMediaIndex(idx)}
                    className={`relative w-20 h-14 rounded-2xl overflow-hidden shrink-0 border-2 transition-all bg-black cursor-pointer ${
                      selectedMediaIndex === idx
                        ? 'border-amber-500 ring-2 ring-amber-500/40'
                        : 'border-[#E5E1DA] dark:border-[#38342D] opacity-60 hover:opacity-100'
                    }`}
                  >
                    {item.type === 'video' ? (
                      <video src={item.url} className="w-full h-full object-cover" controls={false} />
                    ) : (
                      <img
                        src={item.url}
                        alt={`Miniatura ${idx + 1}`}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Title and Price */}
          <div className="space-y-2">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <h2
                id="product-detail-title"
                className="text-2xl md:text-3xl font-serif text-[#141414] dark:text-[#FDFCFB] leading-tight flex-1"
              >
                {product.title}
              </h2>
              {/* Text-to-Speech & Share Buttons */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  id="speak-product-btn"
                  onClick={handleSpeakDetails}
                  aria-label={isSpeaking ? 'Pausar leitura de voz' : 'Ouvir detalhes em voz alta'}
                  className={`px-3.5 py-2 rounded-full border font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                    isSpeaking
                      ? 'bg-amber-500 text-slate-950 border-amber-400 animate-pulse'
                      : 'bg-[#F5F2ED] dark:bg-[#25231E] text-[#5A5A40] dark:text-[#D4CEC3] border-[#E5E1DA] dark:border-[#38342D] hover:bg-[#EAE5DD]'
                  }`}
                >
                  {isSpeaking ? (
                    <>
                      <VolumeX className="w-4 h-4" aria-hidden="true" />
                      <span>Parar Voz</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-4 h-4 text-[#5A5A40] dark:text-[#D4CEC3]" aria-hidden="true" />
                      <span>Ouvir</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  id="share-product-btn"
                  onClick={handleCopyShareLink}
                  aria-label="Copiar link de compartilhamento"
                  className="px-3.5 py-2 rounded-full border border-[#E5E1DA] dark:border-[#38342D] bg-[#F5F2ED] dark:bg-[#25231E] text-[#5A5A40] dark:text-[#D4CEC3] hover:bg-[#EAE5DD] transition-all flex items-center gap-1 text-xs font-semibold cursor-pointer"
                >
                  {copySuccess ? (
                    <span className="text-[#2D5A27] dark:text-[#74BF6B] font-bold">Copiado!</span>
                  ) : (
                    <>
                      <Share2 className="w-4 h-4" aria-hidden="true" />
                      <span>Compartilhar</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Price tag in Kwanzas (AOA) */}
            <div className="flex items-baseline gap-3 pt-1">
              <span className="text-3xl md:text-4xl font-extrabold text-[#2D5A27] dark:text-[#74BF6B] tracking-tight">
                {product.price.toLocaleString('pt-AO')} AOA
              </span>
              <span className="text-xs text-[#8C8273] dark:text-[#A39B8B] font-medium">
                Kwanzas (Pagamento via Multicaixa Express)
              </span>
            </div>

            {/* Location */}
            <div className="flex items-center gap-2 text-sm text-[#4A443A] dark:text-[#D4CEC3] pt-1">
              <MapPin className="w-4 h-4 text-[#8C8273] shrink-0" aria-hidden="true" />
              <span>{product.location}</span>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2 pt-3 border-t border-[#E5E1DA] dark:border-[#38342D]">
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#8C8273]">
              Descrição do Produto
            </h3>
            <p className="text-[#4A443A] dark:text-[#D4CEC3] text-sm md:text-base leading-relaxed whitespace-pre-line">
              {product.description}
            </p>
          </div>

          {/* Tags */}
          {product.tags && product.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 pt-1">
              {product.tags.map((tag, idx) => (
                <span
                  key={idx}
                  className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium bg-[#F5F2ED] dark:bg-[#25231E] text-[#5A5A40] dark:text-[#D4CEC3] border border-[#E5E1DA] dark:border-[#38342D]"
                >
                  <Tag className="w-3 h-3 text-[#8C8273]" aria-hidden="true" />
                  {tag}
                </span>
              ))}
            </div>
          )}

          {/* Seller Card & Direct Social Links */}
          <div className="p-5 rounded-2xl bg-white dark:bg-[#25231E] border border-[#E5E1DA] dark:border-[#38342D] space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <img
                  src={product.seller?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80'}
                  alt={`Vendedor ${product.seller?.name || 'Vendedor'}`}
                  className="w-12 h-12 rounded-full object-cover border-2 border-[#E5E1DA] dark:border-[#38342D] shadow-xs"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <div className="flex items-center gap-1.5 font-semibold text-sm text-[#1A1A1A] dark:text-[#FDFCFB]">
                    <span>{product.seller?.name || 'Vendedor Verificado'}</span>
                    <ShieldCheck className="w-4 h-4 text-emerald-600" aria-label="Vendedor Verificado" />
                  </div>
                  <div className="flex items-center gap-3 text-xs text-[#8C8273] dark:text-[#A39B8B] mt-0.5">
                    <span className="flex items-center gap-1 text-[#5A5A40] dark:text-[#D4CEC3] font-bold">
                      <Star className="w-3.5 h-3.5 fill-[#5A5A40]" aria-hidden="true" />
                      {product.seller?.rating || 4.9}
                    </span>
                    <span>•</span>
                    <span>{product.seller?.totalSales || 30} vendas</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Direct Contact Buttons (Phone, WhatsApp, Instagram, Facebook, TikTok) */}
            <div className="border-t border-[#EBE7DF] dark:border-[#38342D] pt-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#8C8273] dark:text-[#A39B8B] mb-2.5">
                Falar com o Vendedor:
              </h4>
              <div className="flex flex-wrap gap-2">
                {sellerPhone && (
                  <a
                    href={`tel:${sellerPhone}`}
                    className="flex items-center gap-1.5 bg-[#F5F2ED] dark:bg-[#1E1C18] text-[#141414] dark:text-[#FDFCFB] border border-[#E5E1DA] dark:border-[#38342D] px-3.5 py-2 rounded-xl text-xs font-bold hover:bg-[#EAE5DD] transition-colors"
                  >
                    <Phone className="w-3.5 h-3.5 text-stone-600 dark:text-stone-300" />
                    <span>Ligar: {sellerPhone}</span>
                  </a>
                )}

                {sellerPhone && (
                  <a
                    href={`https://wa.me/${whatsappNumber}`}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 bg-emerald-600 text-white px-3.5 py-2 rounded-xl text-xs font-bold hover:bg-emerald-700 shadow-xs transition-colors"
                  >
                    <MessageCircle className="w-3.5 h-3.5 fill-white" />
                    <span>WhatsApp</span>
                  </a>
                )}

                {socialLinks.instagram && (
                  <a
                    href={socialLinks.instagram.startsWith('http') ? socialLinks.instagram : `https://instagram.com/${socialLinks.instagram.replace('@', '')}`}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-3.5 py-2 rounded-xl text-xs font-bold hover:opacity-95 shadow-xs transition-opacity"
                  >
                    <Instagram className="w-3.5 h-3.5" />
                    <span>Instagram</span>
                  </a>
                )}

                {socialLinks.facebook && (
                  <a
                    href={socialLinks.facebook.startsWith('http') ? socialLinks.facebook : `https://facebook.com/${socialLinks.facebook}`}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 bg-blue-600 text-white px-3.5 py-2 rounded-xl text-xs font-bold hover:bg-blue-700 shadow-xs transition-colors"
                  >
                    <Facebook className="w-3.5 h-3.5 fill-white" />
                    <span>Facebook</span>
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Footer with Primary Action Buttons */}
        <div className="p-5 md:p-6 bg-[#F5F2ED]/70 dark:bg-[#181613]/70 border-t border-[#E5E1DA] dark:border-[#38342D] flex flex-col gap-3">
          {/* Admin Moderation Bar */}
          {currentUser?.role === 'admin' && onDeleteProduct && (
            <div className="p-3 rounded-2xl bg-amber-500/10 dark:bg-amber-500/20 border border-amber-400/40 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-700 dark:text-amber-300" aria-hidden="true" />
                <span className="text-xs font-bold text-amber-900 dark:text-amber-200">
                  Painel de Moderação Admin
                </span>
              </div>
              <button
                type="button"
                id="admin-delete-product-btn"
                onClick={() => {
                  if (window.confirm(`Como Administrador, deseja remover permanentemente o anúncio "${product.title}"?`)) {
                    onDeleteProduct(product.id);
                    onAnnounce(`Anúncio ${product.title} removido com sucesso pelo Administrador`);
                    onClose();
                  }
                }}
                className="px-3.5 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Excluir Anúncio (Admin)</span>
              </button>
            </div>
          )}

          {/* Destacar com Multicaixa Express (Se for dono ou admin) */}
          {(currentUser?.id === product.seller_id || currentUser?.role === 'admin') && (
            <button
              type="button"
              id="detail-boost-express-btn"
              onClick={() => {
                setShowExpressModal(true);
                onAnnounce('Abrindo opções de pagamento Multicaixa Express para destacar o anúncio');
              }}
              className="w-full py-2.5 px-4 rounded-xl bg-amber-500/10 dark:bg-amber-400/10 hover:bg-amber-500/20 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-700/60 flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              <span>Destacar este Anúncio no Topo (1.000 Kz via Express)</span>
            </button>
          )}

          {/* Direct Checkout Form / Button */}
          {showOrderCheckout ? (
            <form onSubmit={handleDirectBuy} className="p-4 rounded-2xl bg-white dark:bg-[#201E1A] border border-emerald-300 dark:border-emerald-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider flex items-center gap-1.5">
                  <ShoppingBag className="w-4 h-4 text-emerald-600" />
                  Comprar Direto pelo Site (Express)
                </span>
                <button
                  type="button"
                  onClick={() => setShowOrderCheckout(false)}
                  className="text-xs text-stone-400 hover:text-stone-600"
                >
                  Cancelar
                </button>
              </div>

              {orderResult ? (
                <div className={`p-3 rounded-xl text-xs ${orderResult.success ? 'bg-emerald-50 text-emerald-900' : 'bg-red-50 text-red-900'}`}>
                  <p className="font-bold">{orderResult.message}</p>
                  {orderResult.summary && (
                    <div className="mt-2 space-y-0.5 text-[11px] opacity-90">
                      <p>Total pago: <strong>{orderResult.summary.totalPaid.toLocaleString('pt-AO')} AOA</strong></p>
                      <p>Comissão do site (5%): {orderResult.summary.siteFee.toLocaleString('pt-AO')} AOA</p>
                      <p>Repassado ao vendedor (95%): {orderResult.summary.sellerReceived.toLocaleString('pt-AO')} AOA</p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                      Número do seu Multicaixa Express
                    </label>
                    <div className="relative">
                      <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-stone-400">+244</span>
                      <input
                        type="tel"
                        maxLength={9}
                        value={buyerPhone}
                        onChange={(e) => setBuyerPhone(e.target.value.replace(/\D/g, ''))}
                        className="w-full pl-14 pr-3 py-2.5 rounded-xl border border-stone-300 dark:border-stone-700 bg-[#FDFCFB] dark:bg-[#181613] text-sm font-semibold"
                        placeholder="924 258 402"
                        required
                      />
                    </div>
                  </div>

                  <div className="text-[11px] text-stone-500 bg-stone-50 dark:bg-stone-900/50 p-2.5 rounded-xl border border-stone-200 dark:border-stone-800">
                    Ao confirmar, será enviada uma autorização de <strong>{product.price.toLocaleString('pt-AO')} AOA</strong> para o seu aplicativo Multicaixa Express.
                  </div>

                  <button
                    type="submit"
                    disabled={isOrdering}
                    className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isOrdering ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Enviando cobrança Express...</span>
                      </>
                    ) : (
                      <>
                        <ShoppingBag className="w-4 h-4" />
                        <span>Confirmar Pagamento de {product.price.toLocaleString('pt-AO')} AOA</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </form>
          ) : (
            <button
              type="button"
              onClick={() => setShowOrderCheckout(true)}
              className="w-full py-3.5 px-4 rounded-2xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-sm shadow-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <ShoppingBag className="w-5 h-5" />
              <span>Comprar Agora pelo Site ({product.price.toLocaleString('pt-AO')} AOA)</span>
            </button>
          )}

          {/* Chat and WhatsApp standard options */}
          <div className="flex flex-col sm:flex-row items-center gap-3">
            {/* Chat Interno Button */}
            <button
              type="button"
              id="detail-open-chat-btn"
              onClick={() => onOpenChat(product)}
              className={`w-full sm:flex-1 h-12 px-4 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-xs cursor-pointer ${
                isHighContrast
                  ? 'bg-yellow-400 text-black hover:bg-yellow-300 font-black border-2 border-yellow-500'
                  : 'bg-[#5A5A40] hover:bg-[#484833] text-white'
              }`}
            >
              <MessageCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>Chat Interno</span>
            </button>

            {/* WhatsApp Direct Button */}
            <button
              type="button"
              id="detail-open-whatsapp-btn"
              onClick={() => onOpenWhatsApp(product)}
              className={`w-full sm:flex-1 h-12 px-4 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-all text-white shadow-xs cursor-pointer ${
                isHighContrast
                  ? 'bg-emerald-500 text-black hover:bg-emerald-400 font-black border-2 border-emerald-600'
                  : 'bg-[#25D366] hover:opacity-90 active:scale-98'
              }`}
            >
              <Phone className="w-4 h-4 shrink-0 fill-white" aria-hidden="true" />
              <span>WhatsApp</span>
            </button>
          </div>

          <p className="text-[10px] text-center text-[#8C8273] uppercase tracking-tight">
            Negocie com segurança. Pagamentos auditados pela rede EMIS Multicaixa.
          </p>
        </div>
      </div>

      {/* Express Payment Modal for Boosting / Highlighting */}
      <ExpressPaymentModal
        product={product}
        isOpen={showExpressModal}
        onClose={() => setShowExpressModal(false)}
        onAnnounce={onAnnounce}
      />
    </div>
  );
};
