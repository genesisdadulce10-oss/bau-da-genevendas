import React, { useState } from 'react';
import { Product, ProductStatus, User } from '../types';
import { formatPriceBRL } from '../utils/speech';
import { ExpressPaymentModal } from './ExpressPaymentModal';
import { 
  Plus, 
  Trash2, 
  Pause, 
  Play, 
  CheckCircle2, 
  Eye, 
  Tag, 
  TrendingUp, 
  ShoppingBag,
  ExternalLink,
  Phone,
  ShieldCheck,
  Sparkles,
  Flame
} from 'lucide-react';

interface MyListingsViewProps {
  products: Product[];
  currentUserId: string;
  onUpdateStatus: (productId: string, status: ProductStatus) => void;
  onDeleteProduct: (productId: string) => void;
  onSelectProduct: (product: Product) => void;
  onOpenCreateModal: () => void;
  theme: string;
  onAnnounce: (msg: string) => void;
  currentUser?: User;
}

export const MyListingsView: React.FC<MyListingsViewProps> = ({
  products,
  currentUserId,
  onUpdateStatus,
  onDeleteProduct,
  onSelectProduct,
  onOpenCreateModal,
  theme,
  onAnnounce,
  currentUser,
}) => {
  const [adminViewAll, setAdminViewAll] = useState(false);
  const [selectedProductForBoost, setSelectedProductForBoost] = useState<Product | null>(null);
  const isHighContrast = theme === 'high-contrast';
  const isAdmin = currentUser?.role === 'admin';

  const myProducts = adminViewAll && isAdmin
    ? products
    : products.filter((p) => p.seller_id === currentUserId);

  const activeCount = myProducts.filter((p) => p.status === 'ACTIVE').length;
  const soldCount = myProducts.filter((p) => p.status === 'SOLD').length;
  const totalValue = myProducts
    .filter((p) => p.status === 'ACTIVE')
    .reduce((sum, p) => sum + p.price, 0);

  return (
    <div className="space-y-6" id="my-listings-section">
      {/* Header & Stats */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl md:text-3xl font-serif text-[#141414] dark:text-[#FDFCFB]">
              {adminViewAll && isAdmin ? 'Moderação Global de Anúncios' : 'Meus Anúncios Publicados'}
            </h2>
            {isAdmin && (
              <span className="px-2.5 py-0.5 rounded-full bg-[#5A5A40] text-white text-[10px] font-bold">
                ADMIN
              </span>
            )}
          </div>
          <p className="text-sm text-[#8C8273] dark:text-[#A39B8B] mt-0.5">
            {adminViewAll && isAdmin
              ? 'Painel de superusuário: visualize, edite status e remova qualquer anúncio do marketplace.'
              : 'Gerencie a disponibilidade de seus produtos, pause ou confirme vendas.'}
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {isAdmin && (
            <button
              type="button"
              id="toggle-admin-view-btn"
              onClick={() => {
                setAdminViewAll((prev) => !prev);
                onAnnounce(adminViewAll ? 'Exibindo apenas seus anúncios' : 'Exibindo todos os anúncios para moderação admin');
              }}
              className={`h-12 px-4 rounded-2xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all border ${
                adminViewAll
                  ? 'bg-amber-600 text-white border-amber-700 shadow-xs'
                  : 'bg-white dark:bg-[#25231E] text-[#5A5A40] dark:text-[#D4CEC3] border-[#E5E1DA] dark:border-[#38342D]'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>{adminViewAll ? 'Ver Apenas Meus' : 'Moderar Todos (Admin)'}</span>
            </button>
          )}

          <button
            type="button"
            id="create-new-listing-btn"
            onClick={() => {
              onOpenCreateModal();
              onAnnounce('Abrindo formulário para anunciar produto');
            }}
            className="h-12 px-5 rounded-2xl bg-[#5A5A40] hover:bg-[#4A4A34] text-white font-medium text-sm flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Anunciar Produto</span>
          </button>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-[#201E1A] p-4 rounded-2xl border border-[#E5E1DA] dark:border-[#38342D] shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-[#8C8273] dark:text-[#A39B8B] font-semibold uppercase tracking-wider">
              Anúncios Ativos
            </span>
            <div className="text-2xl font-bold text-[#141414] dark:text-[#FDFCFB] mt-1">
              {activeCount}
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-[#EAF3E8] dark:bg-[#1E2E1D] flex items-center justify-center text-[#2D5A27] dark:text-[#74BF6B]">
            <Tag className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white dark:bg-[#201E1A] p-4 rounded-2xl border border-[#E5E1DA] dark:border-[#38342D] shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-[#8C8273] dark:text-[#A39B8B] font-semibold uppercase tracking-wider">
              Vendidos
            </span>
            <div className="text-2xl font-bold text-[#141414] dark:text-[#FDFCFB] mt-1">
              {soldCount}
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-[#F5F2ED] dark:bg-[#282520] flex items-center justify-center text-[#5A5A40] dark:text-[#D4CEC3]">
            <ShoppingBag className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white dark:bg-[#201E1A] p-4 rounded-2xl border border-[#E5E1DA] dark:border-[#38342D] shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-[#8C8273] dark:text-[#A39B8B] font-semibold uppercase tracking-wider">
              Total em Estoque
            </span>
            <div className="text-2xl font-bold text-[#2D5A27] dark:text-[#74BF6B] mt-1">
              {formatPriceBRL(totalValue)}
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-[#F8F6F2] dark:bg-[#25231E] flex items-center justify-center text-[#5A5A40] dark:text-[#D4CEC3]">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Listings Table / Cards */}
      {myProducts.length === 0 ? (
        <div className="bg-white dark:bg-[#201E1A] rounded-2xl border border-[#E5E1DA] dark:border-[#38342D] p-12 text-center">
          <div className="w-16 h-16 rounded-full bg-[#F5F2ED] dark:bg-[#282520] flex items-center justify-center mx-auto mb-4 text-[#5A5A40] dark:text-[#D4CEC3]">
            <Tag className="w-8 h-8 opacity-60" />
          </div>
          <h3 className="font-serif text-lg font-bold text-[#141414] dark:text-[#FDFCFB] mb-1">
            Nenhum anúncio encontrado
          </h3>
          <p className="text-sm text-[#8C8273] dark:text-[#A39B8B] max-w-sm mx-auto mb-6">
            Você ainda não publicou nenhum anúncio no marketplace. Comece a vender hoje mesmo!
          </p>
          <button
            type="button"
            onClick={onOpenCreateModal}
            className="px-6 py-3 rounded-2xl bg-[#5A5A40] hover:bg-[#4A4A34] text-white font-medium text-sm inline-flex items-center gap-2 shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Publicar Primeiro Anúncio</span>
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {myProducts.map((product) => {
            const firstImage = product.images?.[0]?.image_url || 'https://images.unsplash.com/photo-1580910051074-3eb694886505?w=400';

            return (
              <div
                key={product.id}
                id={`my-product-${product.id}`}
                className="bg-white dark:bg-[#201E1A] rounded-2xl border border-[#E5E1DA] dark:border-[#38342D] p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-shadow hover:shadow-xs"
              >
                {/* Product Thumbnail & Main Details */}
                <div className="flex items-center gap-3.5 min-w-0">
                  <img
                    src={firstImage}
                    alt={product.title}
                    className="w-16 h-16 rounded-xl object-cover border border-[#E5E1DA] dark:border-[#38342D] shrink-0"
                    referrerPolicy="no-referrer"
                  />

                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span
                        className={`px-3 py-0.5 rounded-full text-[11px] font-bold ${
                          product.status === 'ACTIVE'
                            ? 'bg-[#EAF3E8] text-[#2D5A27] dark:bg-[#1E2E1D] dark:text-[#74BF6B]'
                            : product.status === 'PAUSED'
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                            : 'bg-[#F5F2ED] text-[#8C8273] dark:bg-[#282520] dark:text-[#A39B8B]'
                        }`}
                      >
                        {product.status === 'ACTIVE' ? 'Ativo' : product.status === 'PAUSED' ? 'Pausado' : 'Vendido'}
                      </span>
                      <span className="text-xs text-[#8C8273] dark:text-[#A39B8B] font-medium">
                        {product.condition}
                      </span>
                    </div>

                    <h4 className="font-serif font-bold text-base sm:text-lg text-[#1A1A1A] dark:text-[#FDFCFB] truncate mt-1">
                      {product.title}
                    </h4>

                    <span className="text-lg font-medium text-[#2D5A27] dark:text-[#74BF6B]">
                      {formatPriceBRL(product.price)}
                    </span>
                  </div>
                </div>

                {/* Status Switcher & Actions */}
                <div className="flex items-center flex-wrap gap-2 w-full sm:w-auto justify-end pt-2 sm:pt-0 border-t sm:border-t-0 border-[#E5E1DA] dark:border-[#38342D]">
                  {/* Destacar com Multicaixa Express */}
                  {product.status === 'ACTIVE' && (
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedProductForBoost(product);
                        onAnnounce(`Abrindo opções de destaque Express para ${product.title}`);
                      }}
                      className="px-3 py-2 rounded-xl bg-amber-500/10 dark:bg-amber-400/10 hover:bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-300 dark:border-amber-700/60 flex items-center gap-1.5 text-xs font-bold transition-colors cursor-pointer"
                      title="Destacar no topo com Multicaixa Express"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                      <span>Destacar Express</span>
                    </button>
                  )}

                  {/* View Details */}
                  <button
                    type="button"
                    onClick={() => onSelectProduct(product)}
                    className="px-3 py-2 rounded-xl border border-[#E5E1DA] dark:border-[#38342D] bg-[#F5F2ED] dark:bg-[#25231E] text-[#5A5A40] dark:text-[#D4CEC3] hover:bg-[#EAE5DD] flex items-center gap-1.5 text-xs font-semibold"
                    title="Ver página do anúncio"
                  >
                    <Eye className="w-4 h-4" />
                    <span>Ver</span>
                  </button>

                  {/* Toggle Pause / Resume */}
                  {product.status === 'ACTIVE' ? (
                    <button
                      type="button"
                      onClick={() => {
                        onUpdateStatus(product.id, 'PAUSED');
                        onAnnounce(`Anúncio "${product.title}" foi pausado`);
                      }}
                      className="px-3 py-2 rounded-xl border border-amber-300 bg-amber-50 dark:bg-amber-950 text-amber-800 dark:text-amber-300 hover:bg-amber-100 flex items-center gap-1.5 text-xs font-semibold"
                    >
                      <Pause className="w-4 h-4" />
                      <span>Pausar</span>
                    </button>
                  ) : product.status === 'PAUSED' ? (
                    <button
                      type="button"
                      onClick={() => {
                        onUpdateStatus(product.id, 'ACTIVE');
                        onAnnounce(`Anúncio "${product.title}" foi reativado`);
                      }}
                      className="px-3 py-2 rounded-xl border border-[#2D5A27] bg-[#EAF3E8] dark:bg-[#1E2E1D] text-[#2D5A27] dark:text-[#74BF6B] hover:opacity-90 flex items-center gap-1.5 text-xs font-semibold"
                    >
                      <Play className="w-4 h-4" />
                      <span>Ativar</span>
                    </button>
                  ) : null}

                  {/* Mark as Sold */}
                  {product.status !== 'SOLD' && (
                    <button
                      type="button"
                      onClick={() => {
                        onUpdateStatus(product.id, 'SOLD');
                        onAnnounce(`Anúncio "${product.title}" marcado como vendido`);
                      }}
                      className="px-3 py-2 rounded-xl border border-[#E5E1DA] dark:border-[#38342D] bg-white dark:bg-[#25231E] text-[#1A1A1A] dark:text-[#FDFCFB] hover:bg-[#F5F2ED] flex items-center gap-1.5 text-xs font-semibold"
                    >
                      <CheckCircle2 className="w-4 h-4 text-[#2D5A27] dark:text-[#74BF6B]" />
                      <span>Marcar Vendido</span>
                    </button>
                  )}

                  {/* Delete */}
                  <button
                    type="button"
                    onClick={() => {
                      if (confirm(`Tem certeza que deseja excluir o anúncio "${product.title}"?`)) {
                        onDeleteProduct(product.id);
                        onAnnounce(`Anúncio "${product.title}" excluído`);
                      }
                    }}
                    className="p-2 rounded-xl border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950 text-red-700 dark:text-red-300 hover:bg-red-100 flex items-center text-xs font-semibold"
                    title="Excluir anúncio"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Express Payment Modal for Boosting / Highlighting */}
      <ExpressPaymentModal
        product={selectedProductForBoost}
        isOpen={Boolean(selectedProductForBoost)}
        onClose={() => setSelectedProductForBoost(null)}
        onAnnounce={onAnnounce}
      />
    </div>
  );
};
