import { initializeApp, getApps, getApp } from 'firebase/app';
import { getMessaging, getToken, onMessage, isSupported } from 'firebase/messaging';

// Configurações do Firebase vindas de variáveis de ambiente ou fallback
const metaEnv = (typeof import.meta !== 'undefined' && (import.meta as unknown as { env: Record<string, string> })?.env) || {};

const firebaseConfig = {
  apiKey: metaEnv.VITE_FIREBASE_API_KEY || 'SUA_API_KEY',
  authDomain: metaEnv.VITE_FIREBASE_AUTH_DOMAIN || 'bau-da-genevendas.firebaseapp.com',
  projectId: metaEnv.VITE_FIREBASE_PROJECT_ID || 'bau-da-genevendas',
  messagingSenderId: metaEnv.VITE_FIREBASE_MESSAGING_SENDER_ID || '123456789012',
  appId: metaEnv.VITE_FIREBASE_APP_ID || '1:123456789012:web:abcdef123456',
};

const VAPID_KEY = metaEnv.VITE_FIREBASE_VAPID_KEY || 'SUA_VAPID_KEY_DO_FIREBASE';

let messagingInstance: ReturnType<typeof getMessaging> | null = null;

export async function getFirebaseMessaging() {
  if (typeof window === 'undefined') return null;

  try {
    const supported = await isSupported();
    if (!supported) return null;

    const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
    if (!messagingInstance) {
      messagingInstance = getMessaging(app);
    }
    return messagingInstance;
  } catch (err) {
    console.warn('Firebase Messaging não suportado neste navegador:', err);
    return null;
  }
}

/**
 * Envia o token FCM para o backend com autenticação JWT
 */
export const saveDeviceTokenToBackend = async (fcmToken: string): Promise<Response> => {
  const authToken = typeof window !== 'undefined' ? localStorage.getItem('authToken') : null;

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (authToken) {
    headers['Authorization'] = `Bearer ${authToken}`;
  }

  return await fetch('/api/admin/register-device', {
    method: 'POST',
    headers,
    body: JSON.stringify({ token: fcmToken }),
  });
};

/**
 * Função para registrar o dispositivo atual como o principal para receber notificações
 */
export const registerMainDevice = async (onStatus?: (status: { success: boolean; message: string; token?: string }) => void) => {
  try {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      onStatus?.({ success: false, message: 'Notificações não suportadas neste navegador.' });
      return;
    }

    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      let deviceToken = `device-token-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;

      const messaging = await getFirebaseMessaging();
      if (messaging && VAPID_KEY && VAPID_KEY !== 'SUA_VAPID_KEY_DO_FIREBASE') {
        try {
          const fcmToken = await getToken(messaging, { vapidKey: VAPID_KEY });
          if (fcmToken) {
            deviceToken = fcmToken;
          }
        } catch (tokenErr) {
          console.warn('Usando identificador local de dispositivo push:', tokenErr);
        }
      }

      // Envia o token para o backend associá-lo como o dispositivo principal
      const response = await saveDeviceTokenToBackend(deviceToken);

      if (response.ok) {
        localStorage.setItem('admin_device_token', deviceToken);
        console.log('Dispositivo registrado para receber todas as notificações!');
        onStatus?.({
          success: true,
          message: 'Token salvo com sucesso no banco de dados e vinculado ao dispositivo!',
          token: deviceToken,
        });
      } else {
        onStatus?.({ success: false, message: 'Falha ao registrar token no servidor.' });
      }
    } else {
      onStatus?.({ success: false, message: 'Permissão de notificação foi negada pelo usuário.' });
    }
  } catch (error) {
    console.error('Erro ao solicitar permissão de notificação:', error);
    onStatus?.({ success: false, message: 'Erro ao registrar dispositivo.' });
  }
};

/**
 * Escutar notificações quando o aplicativo estiver aberto
 */
export const setupNotificationListener = (
  onReceive: (payload: { title?: string; body?: string }) => void
) => {
  getFirebaseMessaging().then((messaging) => {
    if (messaging) {
      try {
        onMessage(messaging, (payload) => {
          console.log('Notificação recebida em tempo real:', payload);
          onReceive({
            title: payload.notification?.title || 'Nova Notificação',
            body: payload.notification?.body || '',
          });
        });
      } catch (err) {
        console.warn('Erro ao configurar listener do Firebase:', err);
      }
    }
  });
};
